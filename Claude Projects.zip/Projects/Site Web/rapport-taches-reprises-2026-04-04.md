# Rapport — Tâches reprises automatiquement
*Tâche de fond exécutée le 4 avril 2026 (mise à jour ~22h)*

---

## Résumé rapide

Cinq éléments suivis. Site V2 propre et zippé. Canva Baluchon partiellement complété — deux sessions actives bloquées sur des appels API Canva.

---

## ✅ Tâche 1 — Email Cloudflare encodé dans le site V2 (corrigé)

**Pages corrigées :**
- `site_v2/index.html` (footer — colonne Contact)
- `site_v2/services/referencement-naturel/index.html` (footer — colonne Contact)

**Correction appliquée :**
Remplacement du `<span class="__cf_email__">` par l'email en clair
`bonjour@genevievebergeron.ca`.

---

## 🔄 Tâche 2 — Slides Baluchon dans Canva (sessions bloquées)

**Design actif :** `DAHFvFeOkog` — Presentation - Le Baluchon (15 pages, mis à jour)

**État actuel vérifié à ~22h :**

| Slide | Contenu présent |
|-------|----------------|
| Intro / Titre | ✅ Complet |
| Ce que tu vas accomplir | ✅ Complet |
| Comment se passera ta mini-formation | ✅ Complet |
| Module 1 — Pourquoi 3 pages ? | ✅ Complet |
| Module 2 — L'agent IA (Le Radar) | ✅ Complet |
| Module 3 — La Pieuvre | ✅ Complet |
| Module 4 — Rédaction magnétique (header) | ⚠️ Header seulement — **les 4 règles manquent** |
| Module 5 — Le plan d'exécution | ⚠️ Jour 1 + Jour 2 présents, **Jours 3/4/5 manquants** |
| Ce que tu as dans ton Baluchon | ⚠️ En-tête seulement — **la liste d'outils manque** |

**Sessions actives (bloquées sur API Canva) :**
- `local_5f4cb649` "Background ltf" → 48 tours, bloqué sur `commit-editing-transaction`
- `local_d96a0adc` "Background" → 52 tours, bloqué sur `perform-editing-operations`

**⚠️ Action recommandée :** Ces sessions semblent bloquées sur des appels Canva qui ne répondent plus. Si elles ne progressent pas d'ici la prochaine passe, il faudra rouvrir Canva manuellement et copier-coller le contenu depuis `ltf-baluchon-contenu-slides.md`.

**Contenu manquant à copier manuellement si nécessaire :**

### Module 4 — Les 4 règles (à ajouter dans la slide "Les 4 règles essentielles")

**Règle 1 — Une seule idée par page**
- Google cherche *la* page de référence, pas une encyclopédie généraliste
- Chaque page cible un seul mot-clé principal + ses variantes naturelles

**Règle 2 — La structure avant les mots**
- Un seul H1 en haut de page → des H2 pour chaque sous-question → des H3 pour les détails

**Règle 3 — Écris pour quelqu'un, pas pour un algorithme**
- Longueur idéale : 800 à 1 500 mots pour une page pilier
- Ajoute des exemples locaux, des chiffres, des anecdotes

**Règle 4 — Relie tes pages entre elles**
- Un lien interne = un signal de pertinence pour Google
- Chacune de tes 3 pages doit pointer vers les deux autres

### Module 5 — Jours 3, 4 et 5 (à ajouter)

**Jour 3**
- Mise en ligne et optimisation de la troisième page
- Vérification des balises meta (title + description) sur les 3 pages
- S'assurer que chaque page a un H1 clair et unique

**Jour 4**
- Mailler les 3 pages entre elles (liens internes)
- Vérifier sur mobile que tout s'affiche bien
- Soumettre les 3 URLs à Google pour indexation

**Jour 5**
- Connexion à Google Search Console (si pas déjà fait)
- Vérifier que les 3 pages sont indexées
- Prendre une capture d'écran de ton point de départ → Dans 90 jours, tu reviendras comparer

### Slide finale — Ce que tu as dans ton Baluchon

- ✓ **Le Radar** — ton agent IA pour analyser ton marché
- ✓ **La Pieuvre** — pour identifier les mots-clés qui comptent vraiment
- ✓ **Le guide de rédaction** — les 4 règles à garder à portée de main
- ✓ **Le plan 5 jours** — à imprimer et cocher au fur et à mesure
- ✓ **L'accès à la communauté** — pour poser tes questions en chemin

> "Tu as tout ce qu'il faut pour commencer. La seule chose qui manque encore, c'est ton premier lundi matin avec La Pieuvre ouverte."

---

## ✅ Tâche 3 — Site V2 — Vérification complète des pages (propre)

| Page | Lignes | Geneviève. | fix-mailto | Email footer |
|------|--------|------------|------------|-------------|
| index.html | 1 190 | ✅ | ✅ | ✅ corrigé |
| services/index.html | 855 | ✅ | ✅ | ✅ |
| services/design-graphique | 1 222 | ✅ | ✅ | ✅ |
| services/contenu-editorial | 1 107 | ✅ | ✅ | ✅ |
| services/referencement-naturel | 1 240 | ✅ | ✅ | ✅ corrigé |
| services/automatisations-ia | 959 | ✅ | ✅ | ✅ |
| a-propos | 1 138 | ✅ | ✅ | ✅ |

---

## ✅ Tâche 4 — ZIP site V2 régénéré (~21h32)

Le ZIP `genevievebergeron.zip` (246 Ko, 9 fichiers) est à jour avec toutes les corrections.

---

## ℹ️ Rappel — Fichiers disponibles

| Fichier | Description |
|---------|-------------|
| `site_v2/` | V2 complète du site — corrections Geneviève., curseur, mailto |
| `genevievebergeron.zip` | ZIP du site prêt à déployer sur GreenGeeks |
| `ltf-baluchon-contenu-slides.md` | Contenu Baluchon complet à coller dans Canva |
| `ltf-plateforme-low-ticket.md` | Comparatif plateformes order bump / upsell |
| `forfaits-collaboration-obnl.*` | Forfaits OBNL (docx, html, pdf) |

---

*Rapport mis à jour automatiquement — 4 avril 2026, ~22h*
