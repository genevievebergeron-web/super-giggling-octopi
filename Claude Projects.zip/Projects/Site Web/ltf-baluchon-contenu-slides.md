# Contenu LTF Baluchon — Slides à compléter
*Préparé automatiquement le 3 avril 2026 — À coller dans Canva slide par slide*

---

## Contexte

La présentation a 15 pages. Les modules 4 et 5 sont les plus vides. Voici le contenu
prêt à copier-coller pour chaque section, dans ta voix.

---

## MODULE 4 — Rédaction magnétique

### Titre principal (existant)
**Les 4 règles essentielles pour écrire du contenu qui se classe**

### Les 4 règles (CONTENU MANQUANT → à ajouter)

---

**Règle 1 — Une seule idée par page**
- Google cherche *la* page de référence, pas une encyclopédie généraliste
- Chaque page cible **un seul mot-clé principal** + ses variantes naturelles
- Teste toi-même : "Ma page parle de quoi, en une phrase ?" Si tu hésites, Google aussi

---

**Règle 2 — La structure avant les mots**
- Un seul H1 en haut de page (ton titre)
- Des H2 pour chaque grande sous-question
- Des H3 pour les détails
- → Google lit les titres comme toi tu lis une table des matières

---

**Règle 3 — Écris pour quelqu'un, pas pour un algorithme**
- La longueur idéale : assez longue pour répondre VRAIMENT à la question
  (en général, 800 à 1 500 mots pour une page pilier)
- Intègre ton mot-clé naturellement — si ça sonne bizarre à voix haute, c'est trop forcé
- Ajoute des exemples locaux, des chiffres, des anecdotes — ça fait toute la différence

---

**Règle 4 — Relie tes pages entre elles**
- Un lien interne = un signal de pertinence pour Google
- Chacune de tes 3 pages doit pointer vers les deux autres
- Utilise des ancres descriptives : "voir mon guide sur la rédaction web" plutôt que "cliquez ici"

---

### Slide résumé Module 4 (phrase-clé)
> "Écris pour la personne qui se pose la question. Google suivra."

---

## MODULE 5 — Le plan d'exécution

### Structure complète des 5 jours (COMPLÉTER les jours 3, 4, 5)

**Jour 1 (existant)**
- Diagnostic et analyse initiale du site
- Optimisation de la première page cible

**Jour 2 (existant)**
- Finalisation de la deuxième page clé

**Jour 3 — CONTENU MANQUANT**
- Mise en ligne et optimisation de la troisième page
- Vérification des balises meta (title + description) sur les 3 pages
- S'assurer que chaque page a un H1 clair et unique

**Jour 4 — CONTENU MANQUANT**
- Mailler les 3 pages entre elles (liens internes)
- Vérifier sur mobile que tout s'affiche bien
- Soumettre les 3 URLs à Google pour indexation

**Jour 5 — CONTENU MANQUANT**
- Connexion à Google Search Console (si pas déjà fait)
- Vérifier que les 3 pages sont indexées
- Prendre une capture d'écran de ton point de départ
  → Dans 90 jours, tu reviendras comparer les chiffres

---

### Slide résumé Module 5 (phrase-clé)
> "5 jours pour poser les bases. Les résultats arrivent dans les 90 jours suivants."

---

## Ce que tu as dans ton Baluchon (diapositive finale)

**Contenu suggéré pour compléter la liste des outils :**

- ✓ **Le Radar** — ton agent IA pour analyser ton marché
- ✓ **La Pieuvre** — pour identifier les mots-clés qui comptent vraiment
- ✓ **Le guide de rédaction** — les 4 règles à garder à portée de main
- ✓ **Le plan 5 jours** — à imprimer et cocher au fur et à mesure
- ✓ **L'accès à la communauté** — pour poser tes questions en chemin

**Phrase de fermeture suggérée :**
> "Tu as tout ce qu'il faut pour commencer. La seule chose qui manque encore,
> c'est ton premier lundi matin avec La Pieuvre ouverte."

---

---

## Analyse SEO : est-ce que les bases sont couvertes pour un débutant ?

### Ce qui est bien couvert ✅
- L'importance des pages piliers (Module 1)
- La recherche de mots-clés avec un outil concret (Module 3)
- La rédaction structurée (Module 4)
- L'exécution étape par étape (Module 5)

### Ce qui manque pour quelqu'un qui *ne connaît pas du tout* le SEO ⚠️

| Concept | Présent ? | Suggestion |
|---------|-----------|------------|
| Qu'est-ce que l'indexation ? | Partiellement (Module 1) | Ajouter 1 diapositive intro avec définition simple |
| Qu'est-ce qu'une balise meta description ? | ❌ | Mentionner au Jour 3 du plan |
| Qu'est-ce que Google Search Console ? | ❌ | Mentionner au Jour 5 — bon bridge pour l'upsell |
| Les backlinks existent-ils ? | ❌ | Peut être mentionné comme "prochaine étape" |
| Combien de temps avant les résultats ? | Partiellement | Ajouter au Module 5 : "90 jours pour voir les premiers effets" |

**Recommandation :** Ajouter une diapositive "Lexique express" (Module 0 ou après le titre)
avec 4-5 définitions en 1 ligne chacune :
- SEO = référencement naturel = être visible dans Google sans payer
- Indexation = Google a découvert et enregistré ta page
- Mot-clé = l'expression que ton client tape dans Google
- Page pilier = ta page de référence sur un sujet précis

---

## Recommandations d'upsell / mid-ticket funnel

### Option A — Formation intermédiaire (recommandée) ⭐

**Titre suggéré :** "Google, montre-moi tes stats"
ou : "Connecte ton site à Google en 60 minutes"

**Contenu :**
- Créer et connecter Google Search Console à son site
- Comprendre les données : impressions, clics, position moyenne
- Identifier les pages qui ont du potentiel mais ne convertissent pas
- Ajuster le contenu en fonction des données réelles

**Pourquoi ça marche comme upsell :**
C'est la suite logique du Jour 5 du plan d'exécution. Après avoir mis les 3 pages en ligne,
la question naturelle du client est *"Mais est-ce que ça marche ?"* — tu réponds à ça.

**Format suggéré :** Formation autonome (vidéos + guide), 97 $ à 147 $

---

### Option B — Session hot seat (upsell direct après la formation)

**Titre :** "Revue de tes 3 pages — 90 minutes avec Geneviève"
**Prix :** 200 $ à 250 $
**Déclencheur :** Après les 90 jours post-formation

---

### Option C — Audit SEO complet (pour ceux qui veulent aller plus loin)

Amène directement vers ton service SEO existant.
Segment : ceux qui ont fait les 3 pages et veulent une stratégie globale.

---

## Notes de mise en forme pour Canva

**Pour les slides de règles (Module 4) :**
- Police : cohérente avec tes premières slides raffinées
- Structure : numéro de règle en grand → titre en gras → 3 sous-points max par règle
- Couleur d'accent : orange/corail pour les numéros

**Pour les slides de jours (Module 5) :**
- Format check-list visuel (cases à cocher, palette sobre)
- Jour X en gros → 2-3 actions max, pas plus

**Slide finale "Ce que tu as dans ton Baluchon" :**
- Fond sombre avec liste lumineuse — donne un sentiment de complétude et de valeur
- Chaque item avec une petite icône ou crochet

---

*Fichier créé automatiquement — tâche interrompue reprise le 2026-04-03*
