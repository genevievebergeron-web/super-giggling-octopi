# PAGE DE VENTE — LE BALUCHON SEO IA (26 $)
*Copy complète · Ton Geneviève Bergeron · Cible : Mélissa (chargée communications PME/OBNL)*
*Plateforme : Systeme.io*

---

## SECTION 1 — EN-TÊTE / PRÉ-HEADLINE

*[Petit texte au-dessus du titre principal, en gris ou en orange]*

Pour les chargées de communications et de marketing dans les PME et OBNL québécois

---

## SECTION 2 — HEADLINE PRINCIPALE

# Google voit pas ce que fait ton organisation.
# ChatGPT non plus.
# Voici comment changer ça — en 3 pages, en 5 jours.

---

## SECTION 3 — SOUS-TITRE / PROMESSE

**Le Baluchon SEO IA** est une mini-formation pratique avec des outils prêts à l'emploi et des assistants IA configurés pour la réalité des PME et OBNL québécois.

Résultat : 3 pages piliers optimisées pour Google ET pour les moteurs IA (ChatGPT, Perplexity, Google AI Overviews). Sans agence. Sans jargon. Pour 26 $.

*[Bouton orange] → Je veux Le Baluchon — 26 $*

---

## SECTION 4 — LE PROBLÈME (résonance avec Mélissa)

---

### Ton organisation fait du bon travail. Google, lui, le sait peut-être pas encore.

Tu es la personne responsable des communications. Tu sais que la visibilité en ligne, c'est crucial. Ton patron le sait aussi — et il te le rappelle lors de chaque réunion de bilan.

Le problème, c'est que le SEO, c'est une boîte noire. Tu sais que ça existe. Tu sais que ça compte. Mais personne t'a jamais expliqué *comment ça marche pour vrai*, encore moins comment le faire toi-même avec un budget qui dépend de subventions.

Peut-être que t'as déjà mandaté une agence. Peut-être que t'as eu des livrables bien emballés qui ont coûté cher et rien changé concrètement. Peut-être que t'as passé des heures à lire des articles qui se contredisent tous.

Et maintenant, l'IA change tout. ChatGPT, Perplexity, les réponses générées directement dans Google — c'est une nouvelle façon de chercher et de trouver. Et si ton organisation n'est pas bien positionnée là-dedans, tu es invisible deux fois plutôt qu'une.

---

### Ce qui se passe quand le SEO est laissé de côté :

Le site web existe. Les gens le voient pas.

Les publications sur les réseaux sociaux génèrent de l'engagement pendant 48 heures, puis disparaissent. Le SEO, lui, travaille encore dans 2 ans.

Le budget pub existe pour compenser la visibilité organique qui manque. C'est de l'argent qui part au lieu de rentrer.

Les personnes qui cherchent exactement ce que ton organisation offre trouvent d'abord ta compétition. Pas toi.

Et quand quelqu'un demande à ChatGPT "quel organisme offre [ton service] à [ta ville]?" — la réponse ne mentionne pas ton organisation. Même si tu le mérites.

---

## SECTION 5 — TRANSITION (il y a une autre façon)

---

Le SEO pour les PME et les OBNL, c'est pas une science de rocket. C'est pas non plus quelque chose qui nécessite un budget d'agence ou 6 mois de formation.

Ce que ça prend : une méthode claire. Les bons outils. Et un peu de temps ciblé sur les bonnes pages.

Pas 50 pages. Pas tout le site. **3 pages piliers.** Celles qui vont chercher le plus de trafic qualifié et générer le plus d'action.

C'est exactement ça, Le Baluchon.

---

## SECTION 6 — LA SOLUTION (présentation du produit)

---

## Le Baluchon SEO IA

*26 $ · Accès immédiat · Résultats mesurables en 5 jours*

Le Baluchon, c'est ce que j'aurais voulu avoir quand j'ai commencé à apprendre le SEO : une méthode condensée, des outils qui font le travail lourd, et un chemin clair du point A au point B.

C'est pas un cours de 40 heures. C'est pas un PDF de 200 pages. C'est un baluchon — tu prends ce qu'il te faut, tu pars, tu fais.

---

## SECTION 7 — CE QUE TU REÇOIS

---

### 📹 5 micro-vidéos d'exécution (8 à 12 minutes chacune)

Pas de théorie. Pas de jargon. Chaque vidéo est centrée sur une action concrète.

**Vidéo 1 — Pourquoi 3 pages (et pas 50)**
Comment identifier les pages qui ont le plus de levier pour ton organisation. Critères clairs, exemples québécois.

**Vidéo 2 — L'assistant Le Radar**
Ton assistant IA fait l'analyse de marché à ta place et choisit tes 3 batailles SEO réalistes. Tu lui donnes le contexte de ton organisation, il te donne des mots-clés gagnables et une structure d'URL stratégique.

**Vidéo 3 — La Pieuvre (ton système centralisé)**
Le fichier Google Sheets qui centralise tout : mots-clés, URL, état d'optimisation, suivi de performance. Explications complètes, section par section.

**Vidéo 4 — Rédaction Magnétique**
Les règles pour écrire des pages que Google adore et que les IA citent. Entités sémantiques, écriture épicène, localisation micro, bloc FAQ. Exemples avant/après avec des pages réelles.

**Vidéo 5 — Le plan d'exécution**
Jour 1 à jour 5, qu'est-ce qu'on fait exactement. Plan précis pour que les 3 pages soient optimisées et publiées à la fin de la semaine.

---

### 🐙 La Pieuvre — Ton quartier général SEO (Google Sheets)

Un fichier centralisé avec 3 onglets :
- Les 3 Batailles (mots-clés, URL, intention de recherche)
- L'Optimisation par page (H1, meta, FAQ, balises ALT)
- Le Suivi de performance (positions Search Console, clics, impressions)

C'est ton tableau de bord pour les 12 prochains mois. Tu copies, tu colles, tu vois les résultats.

---

### 🤖 L'assistant IA "Le Radar" — configuré et prêt à l'emploi

Pas un outil à apprendre. Pas une plateforme à payer. Un assistant IA déjà configuré avec les règles du marché québécois.

Tu lui donnes le contexte de ton organisation (secteur, ville, service principal, clientèle). Il analyse et te propose tes 3 batailles SEO réalistes avec justifications.

Accès en 3 clics. Explications en vidéo.

---

### 📘 Le guide PDF "Rédaction Magnétique"

Les règles de rédaction qui font qu'une page plaît à Google ET se fait citer par les IA. Concrètes, avec exemples. Format mémo — tu y reviens à chaque fois que tu rédiges.

Ce qui est dedans :
- Les entités sémantiques (en français québécois, pas en traduction d'anglais)
- L'écriture épicène appliquée au SEO
- La structure de FAQ optimisée pour les IA génératives
- La localisation micro pour les organisations qui servent un territoire précis

---

## SECTION 8 — PREUVES / CRÉDIBILITÉ

---

### Pourquoi me faire confiance là-dessus?

Je suis Geneviève Bergeron. Stratège en marketing numérique spécialisée dans le SEO et l'IA pour les PME et OBNL québécois.

Ce qui me différencie des agences que tu as peut-être déjà essayées :

**Je travaille avec le contenu qui existe déjà.** Pas de génération de texte IA-générique. Pas de copy-paste d'anglais. On part de ce que ton organisation fait vraiment, et on le rend compréhensible pour Google et les IA.

**Je forme pour l'autonomie, pas la dépendance.** L'objectif du Baluchon, c'est que tu n'aies plus besoin de moi pour tes 3 pages piliers. C'est ça, la vraie valeur.

**Je connais la réalité des PME et des OBNL.** Le budget limité. Le temps limité. La direction qui veut des résultats concrets. Les subventions qui dictent les priorités. J'adapte les méthodes à ces contraintes-là — pas aux ressources d'une grande entreprise.

**Le SEO organique, c'est aussi la solution durable.** Moins de dépendance aux pubs. Moins de budget gaspillé en ads qui disparaissent dès qu'on arrête de payer. Le SEO travaille encore dans 2 ans. Les pubs, non.

---

## SECTION 9 — POUR QUI C'EST (et pour qui c'est pas)

---

### Le Baluchon SEO IA est fait pour toi si...

Tu es chargée ou chargé de communications ou de marketing dans une PME ou un OBNL québécois — et la visibilité de ton organisation, c'est en partie ta responsabilité.

Tu sais que le SEO compte mais tu sais pas par où commencer.

Tu as un budget limité et tu veux des outils que tu peux utiliser toi-même.

Tu veux comprendre ce que tu fais (pas juste déléguer et payer).

Tu veux pouvoir présenter des résultats concrets à ta direction dans 30 à 90 jours.

---

### Ce n'est pas pour toi si...

Tu cherches quelqu'un pour *faire* tout le SEO à ta place (c'est mon offre d'accompagnement à 800 $+).

Ton site a moins de 6 mois d'existence et n'a pas encore de contenu de base.

Tu travailles dans un marché entièrement anglophone et n'as aucun besoin de présence en français.

---

## SECTION 10 — CTA PRINCIPAL

---

*[Boîte de commande visible, bien centrée]*

## Le Baluchon SEO IA

**26 $** · Accès immédiat

✓ 5 micro-vidéos d'exécution (8-12 min chacune)
✓ La Pieuvre — Système Google Sheets centralisé
✓ Assistant IA "Le Radar" — configuré pour le marché québécois
✓ Guide PDF "Rédaction Magnétique"
✓ Accès à vie à tous les contenus

*[Bouton orange] Oui, je veux Le Baluchon →*

*Paiement sécurisé. Accès immédiat après paiement. Remboursement possible dans les 7 jours si tu réalises que c'est pas pour toi — sans justification.*

---

## SECTION 11 — FAQ

---

### Questions fréquentes

**Est-ce que j'ai besoin d'expertise technique en SEO pour utiliser le Baluchon?**
Non. Le Baluchon est conçu pour les personnes qui font du marketing ou des communications sans être expertes en SEO. Chaque outil est expliqué étape par étape. Si tu sais utiliser Google Sheets et naviguer sur un site web, tu as tout ce qu'il faut.

**Combien de temps est-ce que ça prend vraiment?**
Environ 45 à 90 minutes par jour pendant 5 jours. La plupart des personnes qui ont suivi la méthode bloquent du temps tôt le matin ou en fin d'après-midi. Ce n'est pas un engagement de 40 heures.

**Est-ce que ça marche pour les OBNL ou seulement pour les PME?**
Les deux. La méthode est conçue pour les organisations qui ont une mission à faire rayonner et un budget qui ne permet pas de tout déléguer à une agence. Les OBNL québécois sont particulièrement bien servis par l'approche de localisation micro et d'optimisation pour les recherches communautaires.

**C'est quoi exactement les "assistants IA"? Est-ce que je dois payer pour un abonnement supplémentaire?**
Les assistants IA dans Le Baluchon fonctionnent sur des plateformes accessibles gratuitement ou avec un abonnement de base déjà existant (Claude, ChatGPT ou Poe). Les instructions d'accès sont incluses dans les vidéos. Aucun frais cachés.

**Est-ce que les résultats sont garantis?**
Le SEO, ça prend 4 à 12 semaines pour montrer des résultats mesurables dans Google — c'est la nature de la chose, et n'importe qui qui te promet des résultats en 48 heures te raconte des histoires. Ce que je garantis : la méthode est solide, les outils fonctionnent, et tu vas repartir avec des pages optimisées correctement. Si dans les 7 premiers jours tu réalises que c'est pas pour toi, je te rembourse.

**Et si j'ai des questions après l'achat?**
Tu peux me rejoindre à bonsoir@genevievebergeron.com. Je réponds aux questions courtes. Pour un accompagnement plus poussé, c'est le mid-ticket qui prend le relais.

**En quoi le Baluchon est différent d'un cours SEO que je trouverais sur Udemy?**
Les cours en ligne génériques t'expliquent le SEO en théorie, en anglais, avec des exemples qui ne correspondent pas à la réalité des PME et OBNL québécois. Le Baluchon est conçu pour ton contexte précis — marché francophone, secteur sans ressources illimitées, réalité des recherches locales au Québec — et te donne des outils déjà configurés, pas juste des notions à appliquer.

---

## SECTION 12 — CTA FINAL

---

*[Répétition du bloc de commande]*

## Tu as déjà fait du bon travail.

## Il est temps que Google le sache.

*[Bouton orange] → Obtenir Le Baluchon SEO IA — 26 $*

*Questions? bonsoir@genevievebergeron.com*

---

## SECTION 13 — PIED DE PAGE

Geneviève Bergeron · Stratégie SEO & IA · Montréal, Québec
genevievebergeron.ca · bonsoir@genevievebergeron.com
NEQ : 2280106370

*Politique de confidentialité · Conditions d'utilisation*
*Ce site respecte la Loi 25 du Québec sur la protection des renseignements personnels.*
