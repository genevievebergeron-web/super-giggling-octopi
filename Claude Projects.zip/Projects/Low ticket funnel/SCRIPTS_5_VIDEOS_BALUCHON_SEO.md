# 🎬 PLAN DE MATCH — 5 MICRO-VIDÉOS LE BALUCHON SEO
**Format :** Points clés + transitions · Talking head (intro/conclusion) + Screen share (démos)
**Durée cible :** 8–12 min par vidéo · **Objectif journée :** 5 vidéos claquées, aucun retake inutile

---

## ⏰ HORAIRE DE LA JOURNÉE

| Heure | Bloc | Détail |
|-------|------|--------|
| 8h00 | Setup technique | Vérifier lumière, son, écran propre (fermer notifs), ouvrir tous les onglets nécessaires |
| 8h30 | 🎬 Vidéo 1 | Pourquoi 3 pages piliers |
| 9h30 | 🎬 Vidéo 2 | L'Agent Le Radar |
| 10h45 | ☕ Pause 15 min | Voix + concentration |
| 11h00 | 🎬 Vidéo 3 | La Pieuvre (Sheets) |
| 12h00 | 🍽 Dîner 45 min | Vrai dîner, pas de phone |
| 12h45 | 🎬 Vidéo 4 | Rédaction Magnétique |
| 14h00 | 🎬 Vidéo 5 | Le Plan d'exécution 5 jours |
| 15h00 | 🔁 Retakes ciblés | Maximum 2 prises par section floue, pas plus |

**Règle d'or de la journée :** Une prise, on avance. La perfection tue la livraison.

---

## 📋 CHECKLIST SETUP AVANT DE COMMENCER

**Écran (screen share)**
- [ ] Onglets ouverts : Google Sheets La Pieuvre, Poe (agent Le Radar), exemple de page web PME québécoise
- [ ] Notifications désactivées (téléphone en mode avion, ordinateur en mode ne pas déranger)
- [ ] Zoom in à 125 % sur Sheets pour la lisibilité
- [ ] Fond d'écran épuré (bureau rangé)

**Caméra (talking head)**
- [ ] Lumière face ou légèrement en angle (pas de contre-jour)
- [ ] Micro testé (niveau sonore correct, pas de souffle)
- [ ] Tenue professionnelle mais naturelle
- [ ] Un verre d'eau à portée

---

## 🎬 VIDÉO 1 — POURQUOI 3 PAGES PILIERS
**Durée cible :** 8–10 min | **Format :** Talking head dominant

### 🎯 Objectif de la vidéo
Faire comprendre que le SEO des PME québécoises se gagne ou se perd sur 3 pages stratégiques — pas sur un blogue entier, pas sur 50 URLs.

---

### INTRO — Talking head (1 min)
**Points clés :**
- Accrocher direct : "La plupart des PME québécoises ont des dizaines de pages sur leur site. Google en indexe peut-être 5. Les clients en lisent 3."
- Nommer le problème : énergie dispersée, résultats nuls
- Promettre le résultat : à la fin de cette vidéo, identification des 3 pages qui ont le plus de levier — et pourquoi les autres peuvent attendre

**Transition :** "D'abord, on démystifie ce qu'est une page pilier. Parce que c'est pas juste une belle page — c'est une page qui fait de l'argent."

---

### BLOC 1 — C'est quoi une page pilier (2 min)
**Points clés :**
- Définition simple : une page pilier répond à une intention d'achat ou de décision précise
- 3 types de pages qui méritent l'effort : page de service principal, page d'expertise (crédibilité), page locale (ancrage géographique)
- Exemples concrets québécois : "comptable fiscaliste Rosemont", "garderie non subventionnée Laval", "notaire successions Québec"
- Ce qui N'EST PAS une page pilier : page d'accueil générique, page À propos trop vague, page de blogue sur les tendances

**Transition :** "Maintenant la vraie question : comment trouver TES 3 pages à toi? C'est là que la méthode commence."

---

### BLOC 2 — Les critères de sélection (3 min)
**Points clés :**
- Critère 1 : la page est directement liée à une source de revenus
- Critère 2 : une intention de recherche réelle existe (des gens cherchent ça)
- Critère 3 : la concurrence est réaliste (pas en guerre contre un géant national)
- L'exercice mental : "Si cette page disparaissait demain, est-ce que ça coûterait de l'argent à l'organisation ?" → Si oui, c'est une page pilier candidate
- Piège à éviter : choisir les pages qu'ON aime plutôt que celles que les clients cherchent

**Transition :** "On a les critères. Dans la vidéo 2, l'agent Le Radar fait l'analyse de marché à ta place et choisit tes 3 batailles. Mais avant ça, une dernière chose à retenir sur les pages piliers..."

---

### BLOC 3 — La logique de l'investissement SEO (2 min)
**Points clés :**
- Analogy simple : "Tu répares pas ton toit partout en même temps — tu commences par là où il pleut"
- Une page bien optimisée > dix pages moyennes
- Le SEO est un actif : une page pilier bien faite continue de travailler 12, 24, 36 mois
- L'engagement : dans ce Baluchon, on travaille SEULEMENT ces 3 pages. Pas d'éparpillement.

**Transition :** "C'est ça la discipline de la méthode Octopus. Focus, pas perfection partout."

---

### CONCLUSION — Talking head (1 min)
**Points clés :**
- Récapituler : page pilier = liée aux revenus + intention de recherche réelle + concurrence réaliste
- Action immédiate : ouvrir La Pieuvre (Sheets) et inscrire les 3 candidats — même approximatifs
- Teaser vidéo 2 : "Dans la prochaine vidéo, l'agent Le Radar analyse le marché québécois et confirme ou ajuste ces choix avec des données réelles."

---

## 🎬 VIDÉO 2 — L'AGENT LE RADAR
**Durée cible :** 10–12 min | **Format :** Talking head intro (2 min) + Screen share démo (8 min) + Talking head conclusion (1 min)

### 🎯 Objectif de la vidéo
Montrer comment utiliser l'agent IA Le Radar sur Poe pour analyser le marché québécois et valider les 3 batailles SEO — sans devenir expert en keyword research.

---

### INTRO — Talking head (2 min)
**Points clés :**
- Nommer l'anxiété : "La recherche de mots-clés, ça fait peur. Y'a des outils à 200 $/mois. Des tableaux compliqués. Des experts qui parlent en chiffres."
- La réalité : pour une PME ou un OBNL, on a besoin de 3 mots-clés stratégiques — pas d'un rapport de 50 pages
- Le Radar fait ça : analyse le marché local québécois et propose les 3 batailles réalistes selon la taille et la niche de l'organisation
- Important : Le Radar est un éditeur, pas un générateur — on lui donne le contexte de l'organisation, il travaille AVEC cet input

**Transition :** "On passe à l'écran. Voici exactement comment alimenter Le Radar et lire ses résultats."

---

### DÉMO — Screen share (8 min)

**Étape 1 : Ouvrir l'agent Le Radar sur Poe (1 min)**
- Points clés :
  - Montrer la plateforme Poe, naviguer vers l'agent
  - Expliquer : l'agent a une personnalité configurée — il connaît le marché québécois, il refuse de traduire de l'anglais
  - Le Radar ne génère pas de contenu : il analyse et recommande

**Transition :** "Maintenant on lui donne les informations sur notre organisation."

**Étape 2 : Le brief d'entrée — quoi lui donner (3 min)**
- Points clés :
  - Format du brief : nom de l'organisation + secteur d'activité + ville/région + clientèle principale + service ou programme le plus important
  - Exemple live : utiliser une PME fictive québécoise (ex: firme de comptabilité à Sherbrooke)
  - Ce qu'il NE faut pas faire : copier-coller son site web entier, être vague ("on aide les gens")
  - Le principe : garbage in, garbage out — plus le brief est précis, plus les résultats sont utilisables

**Transition :** "Le Radar analyse. Voici ce qu'il retourne et comment lire les résultats."

**Étape 3 : Lire et interpréter les résultats (4 min)**
- Points clés :
  - Le Radar retourne : 3 mots-clés stratégiques + justification + structure d'URL recommandée
  - Comment valider : est-ce que quelqu'un à Sherbrooke chercherait vraiment ça ?
  - Ajustement si nécessaire : reformuler le brief, préciser la région, préciser le service
  - Ce qu'on garde : les 3 mots-clés retenus vont directement dans La Pieuvre (Sheets)
  - Ce qu'on ignore pour l'instant : toutes les autres suggestions secondaires

**Transition :** "On copie les 3 batailles dans La Pieuvre. C'est la prochaine vidéo."

---

### CONCLUSION — Talking head (1 min)
**Points clés :**
- Récapituler : brief précis → analyse Le Radar → 3 mots-clés + 3 URL stratégiques
- Insister : le but n'est pas le mot-clé parfait — c'est le mot-clé réaliste et payant
- Action immédiate : faire tourner Le Radar avec sa propre organisation avant la vidéo 3
- Teaser : "Dans la vidéo 3, on installe ces 3 batailles dans La Pieuvre — le système qui va tout centraliser."

---

## 🎬 VIDÉO 3 — LA PIEUVRE (GOOGLE SHEETS)
**Durée cible :** 8–10 min | **Format :** Talking head intro (1 min) + Screen share tour guidé (7 min) + Talking head conclusion (1 min)

### 🎯 Objectif de la vidéo
Faire comprendre la logique du fichier La Pieuvre et montrer comment l'utiliser comme quartier général SEO pour les 3 pages piliers.

---

### INTRO — Talking head (1 min)
**Points clés :**
- Problème classique : les décisions SEO se perdent dans des notes Notion, des PDF, des courriels
- La Pieuvre centralise tout : mots-clés, URL, état d'optimisation, résultats
- Un seul fichier = une seule vérité = zéro confusion quand on revient au travail 3 semaines plus tard

**Transition :** "Voici la structure du fichier."

---

### DÉMO — Screen share (7 min)

**Onglet 1 : Les 3 Batailles (2 min)**
- Points clés :
  - Colonnes essentielles : Page, URL, Mot-clé principal, Intention de recherche, Statut (À faire / En cours / Publié)
  - Comment remplir avec les outputs du Radar
  - L'intention de recherche : informationnelle (apprendre), transactionnelle (acheter/contacter), navigationnelle (trouver l'organisation) — on travaille surtout sur transactionnelle
  - Montrer un exemple rempli vs exemple vide

**Transition :** "Une fois les batailles inscrites, on passe à l'onglet d'optimisation."

**Onglet 2 : L'Optimisation par Page (3 min)**
- Points clés :
  - Colonnes : H1 actuel / H1 suggéré, Meta description actuelle / suggérée, Balises ALT images, Nombre de mots approximatif, Présence d'un FAQ
  - Comment auditer rapidement une page existante : ouvrir la page, inspecter, copier les éléments dans le fichier
  - Principe : on diagnostique AVANT de rédiger — pas de rédaction dans le vide
  - Ce qu'on cherche : incohérence entre le titre H1 et le mot-clé cible, meta description manquante ou trop courte, absence de FAQ

**Transition :** "Dernier onglet : le suivi de performance. Celui qu'on va mettre à jour à J+30, J+60, J+90."

**Onglet 3 : Le Suivi (2 min)**
- Points clés :
  - Colonnes simples : Date de publication, Position Google (Search Console), Clics, Impressions
  - Pas besoin de remplir ça aujourd'hui — c'est le tableau de bord dans 30 jours
  - Lien vers Search Console : montrer comment accéder si pas déjà configuré (note : configuration détaillée = vidéo bonus ou La Vigie)
  - L'objectif : voir la progression de position pour les 3 mots-clés sur 3 mois

---

### CONCLUSION — Talking head (1 min)
**Points clés :**
- La Pieuvre n'est pas un outil sophistiqué — c'est un engagement de clarté
- Règle d'utilisation : ouvrir La Pieuvre avant de toucher à une page, fermer La Pieuvre après chaque session
- Action immédiate : copier ses 3 batailles depuis Le Radar, remplir l'onglet 1
- Teaser : "Maintenant qu'on sait QUOI optimiser et OÙ le noter, la vidéo 4 explique COMMENT écrire pour que Google ET les IA adorent la page."

---

## 🎬 VIDÉO 4 — RÉDACTION MAGNÉTIQUE
**Durée cible :** 10–12 min | **Format :** Talking head dominant + Screen share pour exemples avant/après

### 🎯 Objectif de la vidéo
Transmettre les règles de rédaction qui font qu'une page est bien classée sur Google et citée par les IA (GEO) — sans perdre la voix et l'identité de l'organisation.

---

### INTRO — Talking head (2 min)
**Points clés :**
- Le mythe à démolir : "écrire pour le SEO = texte robotique bourré de mots-clés"
- La réalité 2025 : Google et les IA valorisent les textes denses, clairs, avec des entités sémantiques riches
- Ce que la méthode apporte : une façon d'écrire qui plait aux algos ET qui ressemble à l'organisation — pas une traduction de l'anglais, pas du contenu générique
- Annoncer les 4 règles d'or qui vont suivre

**Transition :** "Règle 1 : les entités sémantiques. C'est le concept le plus important — et le plus simple une fois qu'on le comprend."

---

### BLOC 1 — Les entités sémantiques (3 min)
**Points clés :**
- Définition simple : une entité = un nom précis (personne, lieu, concept, organisation) que Google reconnaît et associe à un domaine
- Exemples : "comptable" est un mot. "CPA auditeur Montréal" est une entité. Google comprend la différence.
- Pourquoi ça compte : les IA (ChatGPT, Perplexity) citent les pages riches en entités précises
- Comment l'appliquer : remplacer les pronoms et les vagues par des entités spécifiques
  - Avant : "Notre équipe aide les clients à gérer leurs finances"
  - Après : "Les CPA de la firme XYZ accompagnent les PME manufacturières sherbrookoises dans la gestion de trésorerie et la planification fiscale"
- Transition vers le screen share : montrer un exemple de page avant/après sur l'écran

**[SCREEN SHARE — 1 min]** Exemple de paragraphe transformé

**Transition :** "Règle 2 : l'écriture épicène. C'est la marque de commerce de la méthode — et c'est aussi une question d'accessibilité et de référencement."

---

### BLOC 2 — L'écriture épicène et Zéro Pronom (2 min)
**Points clés :**
- Définition : écriture qui n'assume pas le genre, inclusive, fonctionnelle
- Pourquoi c'est bon pour le SEO : densité de termes précis, pas de pronoms flous que les algos ignorent
- Méthode pratique : remplacer "il/elle" par le nom de l'entité, reformuler avec des infinitifs ou des noms d'action
  - Avant : "Notre cliente a amélioré sa visibilité grâce à notre méthode"
  - Après : "Les résultats : visibilité doublée en 90 jours pour la PME XYZ, secteur services professionnels Québec"
- Règle simple : relire chaque phrase. Si un pronom peut être remplacé par un nom précis, le remplacer.

**Transition :** "Règle 3 : la localisation micro. Et là c'est là qu'on se différencie des agences nationales."

---

### BLOC 3 — La localisation micro (2 min)
**Points clés :**
- Ce que font les agences : "Montréal", "Québec", "Canada"
- Ce que la méthode fait : Rosemont, Villeray, Plateau-Mont-Royal, Verdun, Vieux-Québec, Saint-Sauveur
- Pourquoi : les recherches locales sont moins concurrentielles ET plus intentionnelles (l'internaute cherche vraiment dans ce quartier)
- Comment l'intégrer : mentionner le quartier ou la région dans le H1, dans le premier paragraphe, dans la meta description
- Exemple : "Notaire succession Plateau-Mont-Royal" vs "Notaire Montréal" — compétition totalement différente

**[SCREEN SHARE — 1 min]** Montrer deux pages Google, comparer les résultats locaux vs régionaux

**Transition :** "Dernière règle : le bloc FAQ. C'est ici que ChatGPT et Perplexity viennent chercher leurs réponses."

---

### BLOC 4 — Le bloc FAQ pour être cité par les IA (2 min)
**Points clés :**
- Pourquoi les IA citent les FAQ : format question-réponse direct, facile à extraire
- La structure parfaite : 3 à 5 questions auxquelles les clients posent vraiment, réponses de 2-3 phrases maximum, entités sémantiques dans chaque réponse
- Questions types pour une page de service : "Comment fonctionne [service] ?" "Quel est le délai ?" "Quel est le coût approximatif ?"
- Ce qu'il NE faut pas faire : inventer des questions que personne ne pose, ou copier les FAQ de concurrents

**Transition :** "Ces 4 règles constituent la base de la rédaction magnétique. Le guide PDF dans le Baluchon les détaille avec des exemples sectoriels québécois."

---

### CONCLUSION — Talking head (1 min)
**Points clés :**
- Récapituler les 4 règles : entités sémantiques, écriture épicène/Zéro Pronom, localisation micro, bloc FAQ
- Principe central : écrire pour clarifier, pas pour impressionner
- Action immédiate : prendre une page existante et faire le test — combien de pronoms, combien d'entités précises, est-ce qu'il y a un FAQ ?
- Teaser : "Dans la vidéo 5 — la dernière — on assemble tout dans un plan d'exécution concret : jour 1 à jour 5."

---

## 🎬 VIDÉO 5 — LE PLAN D'EXÉCUTION 5 JOURS
**Durée cible :** 8–10 min | **Format :** Talking head dominant (6 min) + Screen share Sheets (2 min) + Conclusion talking head (2 min)

### 🎯 Objectif de la vidéo
Donner un plan concret, jour par jour, pour optimiser les 3 pages piliers en 5 jours — et fermer avec une invitation à passer à l'Escouade IA (order bump).

---

### INTRO — Talking head (1 min)
**Points clés :**
- Récapituler le chemin parcouru : 3 pages identifiées, Le Radar a confirmé les batailles, La Pieuvre est configurée, les règles de rédaction sont claires
- Ce qui reste : l'exécution. Et c'est là que la plupart abandonnent.
- La solution : un plan précis, jour par jour. Pas d'improvisation.

**Transition :** "Jour 1. On commence par le diagnostic, pas par la rédaction."

---

### BLOC 1 — Jour 1 : Le Diagnostic complet (1,5 min)
**Points clés :**
- Durée réaliste : 45–60 minutes
- Ce qu'on fait : ouvrir La Pieuvre, auditer les 3 pages existantes (H1, meta, FAQ présent ou non, entités)
- Outil : Search Console — voir la position actuelle des 3 pages sur les mots-clés cibles (si pas configuré, noter que c'est une lacune à combler)
- Livrable du jour : La Pieuvre remplie à 100 % pour l'onglet Optimisation
- Ce qu'on ne fait PAS aujourd'hui : écrire ou modifier quoi que ce soit

**Transition :** "Jour 2. On passe en mode rédaction — une page, pas trois."

---

### BLOC 2 — Jour 2 : Optimisation Page 1 (1,5 min)
**Points clés :**
- Durée réaliste : 60–90 minutes
- Focus sur la PAGE PRIORITAIRE NUMÉRO 1 seulement
- Ce qu'on fait : réécrire ou améliorer le H1, la meta description, le premier paragraphe, vérifier les entités, ajouter ou améliorer le FAQ
- Règle du jour : appliquer les 4 règles de rédaction magnétique à chaque modification
- Outils : La Pieuvre pour noter les changements, le guide PDF pour référence
- Livrable : page 1 mise à jour et publiée

**Transition :** "Jour 3 : même exercice, page 2."

---

### BLOC 3 — Jour 3 + Jour 4 : Pages 2 et 3 (1 min)
**Points clés :**
- Même protocole que le jour 2, une page par jour
- Jour 3 → Page pilier 2
- Jour 4 → Page pilier 3
- Si une page nécessite plus de travail (refonte complète du contenu) : noter dans La Pieuvre et traiter séparément — ne pas bloquer le plan
- Garder le rythme, même si les modifications sont petites : une page publiée vaut plus qu'une page parfaite pas publiée

**Transition :** "Jour 5 : on ne rédige plus. On vérifie."

---

### BLOC 4 — Jour 5 : La vérification technique (1,5 min)
**Points clés :**
- Durée réaliste : 30–45 minutes
- Ce qu'on vérifie sur les 3 pages : les titres H1 correspondent-ils aux mots-clés cibles ?, les meta descriptions sont-elles complètes ?, les images ont-elles des balises ALT descriptives ?
- Outil recommandé : Lighthouse (Chrome) → score de performance et d'accessibilité
- Objectif : identifier les blockers techniques évidents (temps de chargement trop lent, images sans ALT)
- Ce qu'on note dans La Pieuvre : score Lighthouse initial, actions techniques à faire

**[SCREEN SHARE — 2 min]** Montrer La Pieuvre remplie à J+5, avec les 3 pages documentées et les cases cochées

**Transition :** "Après le jour 5, qu'est-ce qui se passe ?"

---

### BLOC 5 — L'après : mesurer et ajuster (1 min)
**Points clés :**
- J+30 : retourner dans La Pieuvre, remplir l'onglet Suivi avec les données Search Console
- Ce qu'on cherche : est-ce que la position a bougé ? Est-ce que le CTR a amélioré ?
- Patience SEO : les résultats arrivent dans 4–12 semaines selon la compétitivité du secteur
- Ce qui accélère les résultats : la cohérence des entités sur tout le site, les liens internes vers les pages piliers, la vitesse du site
- Lien vers La Vigie (upsell) : pour celles et ceux qui veulent un système de suivi automatisé sur 12 mois

**Transition :** "Mais avant ça, y'a un raccourci que j'ai envie de te montrer."

---

### CONCLUSION + TRANSITION VERS L'ESCOUADE IA — Talking head (2 min)
**Points clés :**
- Ce que le Baluchon a donné : la stratégie, le système, les règles, le plan
- Ce qui reste le plus long : réécrire les pages. Restructurer les H1-H3. Rédiger les FAQ.
- La bonne nouvelle : c'est exactement ce que font les agents de l'Escouade IA
  - Le Bâtisseur : donne-lui le texte, il sort la hiérarchie parfaite et les meta
  - Le Coach : il nettoie, retire les pronoms, insère le FAQ optimisé
- Pas obligatoire — mais économise 8 à 10 heures sur les 5 jours
- Call to action discret mais clair : "L'Escouade IA, c'est l'ajout à cocher dans la page de commande si tu veux que les robots fassent le travail sale pendant que tu te concentres sur le fond."

---

## 📌 RAPPELS GLOBAUX POUR LE TOURNAGE

**Ton et style**
- Direct. Une idée par phrase. Pas de "en fait", "donc", "genre".
- Zéro jargon sans explication immédiate derrière (si tu dis "GEO", tu expliques en 5 secondes)
- Ancre dans la réalité québécoise : exemples de quartiers, de secteurs locaux, de réalités PME d'ici
- Pas de disclaimers inutiles — pas de "ça peut varier selon les cas", pas de "je suis pas experte mais..."

**Rythme de tournage**
- Erreur de langue ou de mot → continuer et couper au montage (ne pas reprendre depuis le début)
- Silence avant de reprendre → marquer avec une clap de mains pour faciliter le repérage au montage
- Si tu bloques sur une démo à l'écran → dire "je mets pause ici" et couper — pas besoin de tout faire en temps réel

**Fichiers à avoir ouverts pendant le tournage**
- La Pieuvre (Google Sheets) — pour vidéos 3 et 5
- Poe / Agent Le Radar — pour vidéo 2
- Un exemple de page web PME québécoise (fictive ou réelle avec permission) — pour vidéo 4
- Ce document de scripts — pour référence entre les prises
