# VALIDATION STRATÉGIQUE — LTF GENEVIÈVE BERGERON
*Basé sur : Services "ouais pis?", Évaluation de valeur, Client idéal Mélissa, Brand guidelines*

---

## ✅ CE QUI EST SOLIDE — ON GARDE

**La structure des 3 produits** est logique et bien calibrée pour Mélissa.
- 26 $ → 19 $ (order bump, légèrement sous le produit d'appel = prise maximale) → 47 $ (upsell) = logique d'escalier cohérente
- La promesse "3 pages, 5 jours" est concrète, mesurable, réaliste pour une chargée de communications avec peu de temps
- Les outils (Sheets, agents IA) répondent directement au besoin d'autonomie de Mélissa
- Les noms "Le Baluchon", "L'Escouade", "La Vigie" sont québécois, mémorables, distinctifs — **on les garde**

**Le contenu du Baluchon** est bien dosé : méthode + outil + agents IA + guide = haute valeur perçue pour 26 $

**Le positionnement SEO + IA** est pile dans l'angle 2025 : les moteurs de recherche IA (ChatGPT, Perplexity) changent tout — et Mélissa le vit sans savoir quoi faire avec ça.

---

## 🔧 CE QU'ON RECTIFIE

### 1. Retrait complet d'Octopus
Toutes les mentions d'Octopus Marketing Numérique → remplacées par **Geneviève Bergeron** ou **la méthode Geneviève**. La marque personnelle prend le dessus. ✓ Appliqué dans tous les livrables.

### 2. Renommer le produit d'appel
**"Le Baluchon SEO"** → **"Le Baluchon SEO IA"**
Raison : le angle IA est un différenciateur fort en 2025 et répond à l'anxiété de Mélissa face aux changements de l'environnement de recherche. La double promesse (Google + IA) vaut la précision dans le nom.

### 3. Aiguiser le message pour Mélissa spécifiquement
Mélissa n'est pas propriétaire de PME — elle est *responsable des communications dans une organisation*. Elle a un patron, un conseil d'administration, un budget issu de subventions. Le message doit parler à CES réalités :
- Elle a besoin de **montrer des résultats** à quelqu'un
- Elle a peur de **gaspiller un budget déjà serré**
- Elle est méfiante des promesses trop grandes (agences, faux experts)
- Le "faire briller la mission de l'organisation" (OBNL notamment) est un levier émotionnel fort

### 4. Ajouter un lead magnet (freebie) pour nourrir le funnel
Le funnel actuel n'a pas de porte d'entrée gratuite. Sans freebie, il faut payer pour de la publicité pour amener du monde sur la page de vente.

**Freebie recommandé : "Le Bilan SEO en 5 Questions"**
- Mini-diagnostic PDF (1 page recto-verso)
- Complété en 10 minutes
- Score de 0 à 10 avec interprétation
- Résultat naturel : "si tu as scoré 6 ou moins, Le Baluchon est fait pour toi"
- Bonus : Mélissa peut partager les résultats avec sa direction pour justifier l'investissement SEO

### 5. Framing des agents IA — simplifier l'entrée
Les agents Poe peuvent sembler techniques pour Mélissa. Le framing dans tous les textes :
- **Avant :** "Agent IA sur Poe"
- **Après :** "assistant IA configuré pour toi et prêt à l'emploi" ou "robot expert déjà entraîné — tu copies l'accès, tu l'utilises"
Instruction d'accès = 3 étapes maximum dans la livraison.

### 6. Intégrer subtilement l'angle éco-responsable
Mélissa valorise la durabilité. Le fait que le SEO organique = moins de budget pub = moins de gaspillage peut être mentionné — mais jamais comme argument de vente principal. C'est une plus-value dans la chaîne de valeur, pas le cœur de l'offre.

### 7. Graine du mid-ticket à planter dès le Baluchon
Chaque vidéo, chaque courriel, chaque livrable doit contenir une phrase qui plante la graine de l'audit (800 $) :
- "Si tu veux qu'on creuse plus loin ensemble..."
- "L'étape d'après, pour celles et ceux qui veulent plus qu'un moteur propre..."

---

## 📐 STRUCTURE FINALE DU FUNNEL

```
FREEBIE GRATUIT
"Le Bilan SEO en 5 Questions"
→ Livré par courriel → Séquence de 5 courriels → Page de vente

PRODUIT D'APPEL — 26 $
Le Baluchon SEO IA
5 micro-vidéos + La Pieuvre (Sheets) + Agent Le Radar + Guide PDF Rédaction Magnétique

ORDER BUMP — 19 $
L'Escouade IA
Agent Le Bâtisseur + Agent Le Coach + Checklist Lighthouse au Vert

UPSELL — 47 $
La Vigie SEO
Agent L'Analyste + Dashboard Sheets 12 mois + Masterclass L'Écho de l'IA

ESCALIER VERS LE MID-TICKET
→ L'Audit Deep Dive (800 $) : "Geneviève audite ton écosystème complet"
→ L'Accompagnement 360 (2 500 $+) : "Prends les clés"
```

---

## 💡 ANGLES MESSAGING CLÉS (à répéter dans tous les textes)

| Douleur Mélissa | Angle messaging |
|-----------------|-----------------|
| "Mon organisation est invisible sur Google" | "3 pages bien faites changent plus que 50 pages moyennes" |
| "Je comprends pas le SEO / j'ai pas le temps d'apprendre" | "Les robots font le diagnostic et la structure à ta place" |
| "J'ai peur de gaspiller le budget" | "26 $, c'est moins que le dîner de jeudi — et ça travaille encore dans 2 ans" |
| "L'IA transforme tout et je sais pas comment m'adapter" | "ChatGPT, Perplexity, Google — voici comment faire en sorte qu'ils te trouvent tous" |
| "J'ai déjà payé une agence pour des résultats nuls" | "C'est toi qui fais. Moi je te donne la méthode et les outils." |
| "Mon patron veut des résultats mesurables" | "À J+30, tu peux présenter tes données Search Console. C'est du concret." |

---

## 🎯 VALIDATION PRIX

| Produit | Prix | Verdict |
|---------|------|---------|
| Le Baluchon SEO IA | 26 $ | ✅ No-brainer absolu. En dessous du seuil de réflexion pour une chargée à 70-80k/an |
| L'Escouade IA (OB) | 19 $ | ✅ Légèrement sous le produit d'appel = prise maximale à la caisse |
| La Vigie SEO | 47 $ | ✅ Clairement plus cher mais encore accessible. Transition naturelle vers le 800 $ |
| Total LTF complet | 92 $ | ✅ Pour une chargée de communications, 92 $ pour refaire les fondations SEO = deal du siècle |
