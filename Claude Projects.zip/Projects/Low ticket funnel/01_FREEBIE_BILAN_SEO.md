# FREEBIE — LE BILAN SEO EN 5 QUESTIONS
*Lead magnet gratuit pour nourrir le funnel vers Le Baluchon SEO IA*

---

## 📋 STRATÉGIE DU FREEBIE

**Objectif :** Capturer le courriel de Mélissa, lui donner une valeur immédiate, et la préparer émotionnellement à acheter Le Baluchon.

**Logique :** Le bilan crée la prise de conscience (le problème est réel, mesurable) et positionne naturellement Le Baluchon comme la solution logique. Mélissa peut aussi partager ses résultats avec sa direction pour justifier l'investissement en SEO.

**Format livrable :** PDF 1 page recto-verso, design sobre dans l'identité visuelle de Geneviève Bergeron (noir #1a1a1a, orange #ff6b35, blanc cassé #fafafa).

**Titre sur la page de capture :** "Télécharge le Bilan SEO Express — 5 questions pour savoir si Google comprend (vraiment) ce que fait ton organisation."

**CTA page de capture :** "Envoie-moi le bilan" ou "Je veux savoir où j'en suis"

---

## 📄 CONTENU DU FREEBIE (texte complet à mettre en page)

---

### COUVERTURE (recto)

**GENEVIÈVE BERGERON**
*Stratégie SEO & IA · genevievebergeron.ca*

---

# LE BILAN SEO EXPRESS

## 5 questions pour savoir si Google comprend ce que fait ton organisation

*Complète ça en 10 minutes. Les résultats pourraient te surprendre.*

---

**COMMENT UTILISER CE BILAN**

Réponds à chacune des 5 questions en regardant le site web de ton organisation en ce moment (ouvre-le dans un autre onglet). Encercle le chiffre qui décrit le mieux la situation réelle — pas celle que tu voudrais avoir.

Additionne tes points à la fin.

---

**QUESTION 1 — LE TITRE DE TES PAGES**

Ouvre ton site web. Clique sur ta page de services ou ta page principale. Regarde dans l'onglet du navigateur : qu'est-ce qui est écrit?

- **0 point** — "Accueil" ou le nom de l'organisation seulement (ex. "Communications XYZ")
- **1 point** — Le nom de l'organisation + un slogan vague (ex. "Communications XYZ — Ensemble, on avance")
- **2 points** — Le nom de l'organisation + ce que tu fais + pour qui (ex. "Comptabilité pour OBNL à Montréal — Fiducie Larivée")

*Pourquoi ça compte : Google lit les titres d'onglets en premier. Si le titre ne dit pas ce que tu fais et où tu le fais, Google ne peut pas bien te classer.*

---

**QUESTION 2 — LA DESCRIPTION DE TES SERVICES**

Lis la première phrase de ta page de services. Est-ce qu'un·e inconnu·e qui ne connaît pas ton organisation comprendrait exactement ce que tu offres et à qui?

- **0 point** — Non. C'est flou, philosophique ou en jargon interne.
- **1 point** — Un peu. Le service est nommé mais la clientèle cible n'est pas claire.
- **2 points** — Oui. Le service, la clientèle et la région sont tous présents dans les 2 premières phrases.

*Pourquoi ça compte : Google et les IA (ChatGPT, Perplexity) utilisent les premières phrases de chaque page pour décider à qui recommander ton contenu.*

---

**QUESTION 3 — LA PRÉSENCE D'UN FAQ**

Est-ce qu'il y a une section FAQ (foire aux questions) sur au moins une de tes pages de services?

- **0 point** — Non, aucun FAQ nulle part sur le site.
- **1 point** — Il y a un FAQ quelque part, mais les questions sont génériques (ex. "Quel est votre délai de livraison?")
- **2 points** — Il y a un FAQ avec des questions que tes clients posent *vraiment*, et chaque réponse est précise et complète.

*Pourquoi ça compte : les IA générent leurs réponses à partir de formats question-réponse. Un bon FAQ = plus de chances que ChatGPT ou Perplexity cite ton organisation.*

---

**QUESTION 4 — LA PRÉCISION GÉOGRAPHIQUE**

Est-ce que ton site mentionne clairement où ton organisation opère (ville, région, quartier)?

- **0 point** — Non. Le site pourrait s'appliquer à n'importe quelle ville au Canada.
- **1 point** — La province ou la grande ville est mentionnée une ou deux fois.
- **2 points** — La ville ET le quartier ou la région spécifique apparaissent dans les pages de services ET dans la meta description (le petit texte sous le titre dans Google).

*Pourquoi ça compte : "comptable Montréal" et "comptable Rosemont" ne se battent pas contre les mêmes compétiteurs. La précision géographique est ton meilleur ami si tu sers un territoire précis.*

---

**QUESTION 5 — LA VITESSE ET L'ACCESSIBILITÉ**

Ouvre ton site sur ton téléphone (pas sur ordinateur). Est-ce que la page principale charge en moins de 3 secondes?

- **0 point** — Non. La page prend plus de 3-4 secondes à charger, ou le contenu saute pendant le chargement.
- **1 point** — Oui, ça charge correctement, mais certaines images sont floues ou pixelisées sur mobile.
- **2 points** — Oui. Chargement rapide, images nettes, texte lisible sans zoomer, boutons facilement cliquables.

*Pourquoi ça compte : Google pénalise les sites lents dans son classement. Et depuis 2024, la majorité des recherches se font sur mobile.*

---

### VERSO — RÉSULTATS ET PROCHAINES ÉTAPES

---

## TES RÉSULTATS

**TOTAL : _____ / 10**

---

**8 à 10 points — Fondations solides**

Google comprend ce que fait ton organisation. Les bases sont là. L'étape suivante : approfondir la stratégie de mots-clés, analyser les données de performance et s'assurer que les IA généretives (ChatGPT, Perplexity) recommandent aussi ton contenu. C'est exactement ce que couvre La Vigie SEO.

---

**5 à 7 points — Fondations partielles**

Ton site est visible, mais pas autant qu'il pourrait l'être. Quelques ajustements ciblés sur tes 3 pages les plus importantes feraient une différence réelle. Le Baluchon SEO IA te donne la méthode + les outils + les robots pour faire ça en 5 jours.

---

**0 à 4 points — Les fondations restent à bâtir**

Google et les IA ont du mal à comprendre ce que fait ton organisation — et donc à la recommander. Ce n'est pas une catastrophe, c'est un point de départ. Le Baluchon SEO IA est fait exactement pour toi : méthode claire, outils prêts à l'emploi, résultats concrets en 5 jours.

---

## PAR OÙ COMMENCER?

Peu importe ton score, la prochaine étape logique est la même : identifier tes 3 pages les plus payantes et les optimiser correctement — pour Google ET pour les IA.

**Le Baluchon SEO IA te montre comment faire ça, pas à pas, avec des outils configurés pour la réalité des PME et OBNL québécois.**

→ **genevievebergeron.ca/baluchon** — 26 $, accès immédiat, 5 jours pour des résultats mesurables.

---

*Geneviève Bergeron · Stratégie SEO & IA pour PME et OBNL québécois*
*bonsoir@genevievebergeron.com · genevievebergeron.ca*

---

## 🛠️ NOTES DE MISE EN PAGE

**Police :** Sobre et lisible — Inter ou DM Sans recommandés. H1 en gras, corps de texte léger.
**Couleurs :** Titres en noir #1a1a1a. Scores en orange #ff6b35. Encadrés de résultats sur fond blanc cassé #fafafa avec bordure fine gris clair #e0e0e0.
**Format PDF :** A4 ou Letter. Recto-verso pour l'impression, pages séparées pour le numérique.
**CTA final :** Lien cliquable en orange dans le PDF numérique. Texte URL écrit en clair pour l'impression.

---

## 📧 PAGE DE CAPTURE — TEXTE COMPLET

**Titre H1 :** Google comprend-il vraiment ce que fait ton organisation?

**Sous-titre :** Un bilan express — 5 questions, 10 minutes, une réponse claire — pour savoir si les fondations SEO sont en place.

**Corps :**
Les PME et OBNL québécois font du bon travail. Souvent, Google le voit pas encore.

Pas parce que le travail est mauvais. Parce que les signaux envoyés à Google sont flous, incomplets, ou absents. Et depuis que ChatGPT et Perplexity répondent aux questions à la place de Google, les enjeux ont doublé.

Ce bilan de 5 questions t'aide à voir exactement où en est ton organisation — et ce qui bloquerait Google (et les IA) de te recommander.

Gratuit. Utile. Sans jargon.

**Champ courriel :** Ton adresse courriel

**CTA bouton (orange) :** Envoie-moi le bilan →

**Sous le bouton (petit texte) :** Aucun spam. Tu peux te désabonner n'importe quand. Promesse d'humain, pas de robot.
