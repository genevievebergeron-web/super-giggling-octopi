# ORDER BUMP + UPSELL — L'ESCOUADE IA (19 $) + LA VIGIE SEO (47 $)

---

# PARTIE 1 — ORDER BUMP : L'ESCOUADE IA (19 $)

*Apparaît sur la page de paiement du Baluchon, sous le formulaire de carte de crédit, sous forme de case à cocher.*

---

## TEXTE DE L'ORDER BUMP (version complète)

---

*[Encadré distinct, fond légèrement coloré — blanc cassé ou orange très pâle, bordure orange]*

**⬜ Oui, ajoute L'Escouade IA à ma commande — +19 $**

### L'Escouade IA : tes deux robots pour faire le travail de rédaction en quelques clics

Le Baluchon te donne la méthode. L'Escouade fait le travail lourd à ta place.

Réécrire les titres H1, structurer les sous-titres H2-H3, rédiger des meta descriptions qui donnent le goût de cliquer, ajouter les balises ALT sur les images, nettoyer le texte et insérer un bloc FAQ optimisé pour les IA — c'est exactement ce qui prend le plus de temps dans l'optimisation d'une page.

L'Escouade te donne accès à deux assistants IA déjà configurés pour faire ça :

**Le Bâtisseur** — Tu lui donnes ton texte de page. Il te retourne la hiérarchie H1-H3 parfaite, les meta descriptions et les suggestions de balises ALT. Prêt à copier-coller dans ton CMS.

**Le Coach** — Il édite ton texte pour le rendre dense et précis : retire les pronoms flous, solidifie les formulations, ajoute un bloc FAQ spécialement structuré pour être cité par les IA (ChatGPT, Perplexity).

**Bonus : La Checklist "Lighthouse au Vert"** — Les vérifications techniques essentielles pour la performance et l'accessibilité de chaque page. En clair, sans jargon.

Gain de temps estimé : 8 à 10 heures sur les 5 jours d'exécution.

*À 19 $, c'est la décision la plus logique que tu prendras aujourd'hui.*

---

## VERSION COURTE (si la plateforme impose une limite de mots)

**⬜ Ajouter L'Escouade IA — +19 $**

Deux assistants IA configurés pour faire le travail de structure et de rédaction à ta place : Le Bâtisseur (hiérarchie H1-H3, meta, balises ALT) + Le Coach (nettoyage rédactionnel + FAQ optimisé pour les IA). Économise 8 à 10 heures d'exécution.

---

## NOTES DE PRÉSENTATION

- L'encadré doit être visible immédiatement sous le formulaire de paiement, avant le bouton de confirmation
- La case doit être décochée par défaut (pas pré-cochée — c'est une pratique manipulatrice à éviter)
- Le prix total doit se mettre à jour automatiquement si la case est cochée (26 $ → 45 $)

---
---

# PARTIE 2 — UPSELL : LA VIGIE SEO (47 $)

*Page séparée qui apparaît immédiatement après la confirmation d'achat du Baluchon. L'accès aux produits achetés n'est pas encore livré — l'upsell est présenté en premier.*

---

## PAGE UPSELL COMPLÈTE

---

### EN-TÊTE

*[Petit texte de contexte, en gris]*
Attends — ton accès au Baluchon arrive dans une minute. D'abord, une question.

---

### HEADLINE

# Tu viens de poser les fondations.
# Et dans 90 jours, comment tu vas savoir si ça marche?

---

### CORPS PRINCIPAL

Tu viens d'investir dans la méthode pour optimiser tes 3 pages piliers. C'est la bonne décision.

Maintenant, voici ce qui arrive souvent après : les pages sont publiées, le travail est fait — et personne regarde les données pour voir si ça a changé quelque chose. Pas parce que les gens sont négligents. Parce que Google Search Console, ça peut être intimidant. Et parce que savoir quoi regarder, c'est pas évident.

La Vigie SEO, c'est l'étape d'après. Le système pour ne pas perdre ce que tu viens de construire — et pour continuer à progresser sans recommencer à zéro.

---

### CE QUE CONTIENT LA VIGIE SEO

---

**📊 L'assistant IA "L'Analyste" — ton expert en données SEO**

Tu lui donnes tes données de Google Search Console (un simple export en CSV). Il analyse et t'identifie :

- Tes pages coincées en page 2 de Google (entre la 11e et la 20e position) — c'est souvent là que se cache le plus gros potentiel
- Tes pages avec un CTR faible (le site apparaît mais les gens cliquent pas — c'est un signal de meta description à améliorer)
- Tes requêtes de recherche sous-exploitées (des expressions pour lesquelles ton site commence à être visible sans que tu l'aies prévu)

Pas besoin d'être analyste de données. Tu exécutes les étapes dans L'Analyste, il fait le diagnostic.

---

**📈 Le Dashboard de Performance — 12 mois de suivi automatisé**

Un Google Sheets préconfiguré pour suivre tes 3 pages piliers sur 12 mois.

- Tu entres tes données mensuellement (10 minutes par mois)
- Le tableau calcule automatiquement les progressions
- Tu vois clairement si les pages montent, stagnent ou régressent
- Tu as des données concrètes à présenter à ta direction lors des bilans

C'est la différence entre "on fait du SEO" et "voici les résultats de notre SEO ce trimestre."

---

**🎥 La Masterclass "L'Écho de l'IA" — vidéo exclusive**

La question que tout le monde se pose en 2025 : "Est-ce que ChatGPT parle de nous?"

Cette vidéo t'explique exactement comment vérifier si ton organisation est citée par les IA génératives (ChatGPT, Perplexity, Google AI Overviews) — et surtout, quoi faire si la réponse est non.

C'est le chaînon manquant entre le SEO traditionnel (Google) et le SEO de la génération IA (GEO — Generative Engine Optimization).

---

### RÉSUMÉ DU CONTENU

✓ Assistant IA "L'Analyste" — analyse Search Console, prêt à l'emploi
✓ Dashboard Google Sheets 12 mois — suivi automatisé de tes 3 pages piliers
✓ Masterclass "L'Écho de l'IA" — comment vérifier et améliorer ta présence dans les IA génératives
✓ Accès à vie

---

### ANGLE "OUIN PIS?" (chaîne de valeur)

La Vigie SEO te permet de suivre tes résultats → ouin pis → tu peux montrer des données concrètes à ta direction → ouin pis → tu justifies l'investissement en SEO → ouin pis → tu obtiens plus de budget pour la suite → ouin pis → L'Analyste identifie où est l'argent laissé sur la table → ouin pis → tu sais exactement quoi améliorer → ouin pis → ton trafic continue de croître même après les 5 premiers jours → ouin pis → tu construis une stratégie SEO qui travaille pour toi toute l'année.

---

### CTA UPSELL

*[Bouton orange principal]*
**Oui, j'ajoute La Vigie SEO — +47 $**
*(Total : 73 $ ou 92 $ si L'Escouade a été ajoutée)*

*[Lien texte sous le bouton, en gris discret]*
Non merci, je vais accéder directement au Baluchon →

---

### MICRO-COPY SOUS LE CTA

*Pas de pression. Pas de fausse urgence. La Vigie sera disponible à 67 $ plus tard. Aujourd'hui, c'est 47 $ parce que tu viens d'acheter Le Baluchon.*

---

## NOTES TECHNIQUES (Systeme.io)

- La page upsell doit se présenter AVANT la page de confirmation/livraison
- Le bouton "Non merci" doit mener directement à la page de confirmation
- Le prix final de 47 $ doit être présenté clairement sans frais cachés
- Pas de compte à rebours ou de fenêtre de disponibilité limitée — la transparence est une valeur de la marque
