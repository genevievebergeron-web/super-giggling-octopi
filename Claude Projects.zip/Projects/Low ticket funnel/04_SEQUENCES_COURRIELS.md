# SÉQUENCES DE COURRIELS — LTF GENEVIÈVE BERGERON

*Trois séquences : pré-achat (freebie → vente) + post-achat Baluchon seul + post-achat Baluchon + Escouade*
*Ton : direct, tutoiement, sans BS, sans urgence artificielle, voix de Geneviève*

---

## SÉQUENCE A — PRÉ-ACHAT (freebie → Le Baluchon)
*5 courriels · Déclencheur : téléchargement du Bilan SEO Express*

---

### A1 — IMMÉDIAT · Livraison du freebie

**Objet :** Ton Bilan SEO Express est là (et les résultats pourraient te surprendre)

**Pré-header :** 10 minutes pour savoir où en est ton organisation.

---

Salut,

Ton Bilan SEO Express est attaché à ce courriel. C'est une page, recto-verso, 5 questions.

Ouvre ton site web dans un autre onglet et réponds honnêtement. Pas en fonction de ce que tu voudrais que ce soit — en fonction de ce qui est là *maintenant*.

Additionne tes points à la fin.

Si tu scores 6 ou moins : les fondations SEO de ton organisation restent à bâtir. C'est pas une catastrophe. C'est un point de départ. Et dans les prochains jours, je vais te montrer exactement comment régler ça — rapidement et sans agence.

Si tu scores 7 ou plus : les bases sont là, mais il y a probablement des angles morts. Je t'en parle dans les prochains jours aussi.

Dans tous les cas, bienvenue.

Je suis Geneviève Bergeron. Stratège SEO et IA pour les PME et OBNL québécois. Je suis pas une agence, je suis une personne — et je t'écris directement.

À demain,
Geneviève

*P.S. Si tu as des questions sur le bilan, réponds directement à ce courriel. Je lis tout.*

---

### A2 — J+1 · Éducation (la vérité sur le SEO en 2025)

**Objet :** Ce que personne ne t'a dit sur le SEO (et pourquoi ça change tout)

**Pré-header :** Spoiler : c'est pas ce que tu penses.

---

Salut,

Une chose que j'entends souvent : "Le SEO, ça marche pas pour les organisations comme la nôtre."

Réponse courte : ça marche. Mais probablement pas de la façon dont on te l'a expliqué.

Le SEO, dans sa version simple, c'est ça : est-ce que Google comprend ce que fait ton organisation, pour qui, et où? Si la réponse est oui, tu vas apparaître dans les résultats de recherche quand les bonnes personnes cherchent ce que tu offres. Si la réponse est non — et c'est le cas pour la majorité des PME et OBNL québécois — ton organisation est invisible, même si le travail est excellent.

Ce que beaucoup de gens ne savent pas encore : depuis 2023-2024, les moteurs de recherche changent. ChatGPT, Perplexity et Google lui-même génèrent des réponses directes aux questions des utilisateurs et utilisatrices. Si ton organisation n'est pas bien positionnée dans ces résultats-là, tu es invisible *deux fois*.

La bonne nouvelle : les règles de base n'ont pas changé. On optimise pour Google, on est bien positionné pour les IA aussi.

La mauvaise nouvelle : la plupart des organisations continuent d'espérer que ça se règle tout seul.

Demain, je t'explique concrètement ce qui bloque Google de comprendre ta page de services — même quand le contenu est là.

Geneviève

---

### A3 — J+2 · Éducation (ce qui bloque concrètement)

**Objet :** Les 3 choses qui font que Google ignore ton site (sans que tu le saches)

**Pré-header :** Ce sont des fixs simples. Mais encore faut-il les voir.

---

Salut,

Trois signaux que Google et les IA interprètent comme "je comprends pas ce que tu fais" :

**1. Le titre de page qui dit rien**
"Accueil" comme titre d'onglet. Ou juste le nom de l'organisation. C'est comme mettre "Bâtiment" sur la porte de ton bureau au lieu de "Clinique de physiothérapie sportive — Verdun".

**2. Le premier paragraphe qui parle de toi, pas de qui tu aides**
"Depuis 2010, notre équipe dévouée..." → Google s'en fout (et les gens aussi, soyons honnêtes). Ce que Google cherche : le service + la clientèle + le territoire. Dans les deux premières phrases.

**3. L'absence de bloc FAQ**
Les IA génératives (ChatGPT, Perplexity) adorent le format question-réponse. Si ton site n'en a pas, les IA vont citer quelqu'un d'autre à ta place.

Ces trois choses-là, c'est ce que je règle avec mes clients en priorité. Pas parce que c'est les plus glamour — parce que c'est là que l'impact est le plus rapide et le plus mesurable.

Demain, je te présente comment j'ai condensé ça en une méthode de 5 jours.

Geneviève

---

### A4 — J+3 · Présentation du produit (page de vente)

**Objet :** Le Baluchon SEO IA — 26 $ pour refaire les fondations de tes 3 pages clés

**Pré-header :** Méthode + outils + assistants IA configurés. Accès immédiat.

---

Salut,

Pendant les deux derniers jours, on a parlé de ce qui bloque Google de comprendre ton organisation.

Aujourd'hui, je te présente la solution que j'ai construite pour les PME et OBNL québécois qui veulent régler ça sans dépendre d'une agence et sans devenir experte en SEO.

**Le Baluchon SEO IA — 26 $**

C'est une mini-formation pratique de 5 jours, avec :
- 5 micro-vidéos d'exécution (pas de théorie — des actions concrètes)
- La Pieuvre : un fichier Google Sheets centralisé pour tout piloter
- L'assistant IA "Le Radar" : déjà configuré pour analyser le marché québécois et choisir tes 3 batailles SEO réalistes
- Le guide PDF "Rédaction Magnétique" : les règles pour écrire des pages que Google adore et que les IA citent

Résultat : 3 pages piliers optimisées pour Google ET pour les IA génératives — en 5 jours.

→ [Voir ce qui est inclus et obtenir l'accès](genevievebergeron.ca/baluchon)

Ce que Le Baluchon n'est pas : un cours de 40 heures. Un PDF de 200 pages. Une promesse irréaliste de résultats en 48 heures.

Le SEO prend 4 à 12 semaines pour se refléter dans les classements. Ça, je te le dis d'emblée. Mais les fondations que tu vas poser cette semaine vont travailler pour ton organisation encore dans 2 ans.

Geneviève

*P.S. Si tu as des questions avant d'acheter, réponds ici. Je te réponds personnellement.*

---

### A5 — J+5 · Dernier rappel (sans urgence artificielle)

**Objet :** J'allais oublier de te mentionner ça

**Pré-header :** Pas de compte à rebours. Juste une pensée.

---

Salut,

Je t'ai présenté Le Baluchon SEO IA il y a deux jours. Je t'envoie un dernier courriel là-dessus parce que je veux pas que tu passes à côté si c'était pour toi — pas pour créer une urgence artificielle qui existe pas.

La vérité : Le Baluchon est disponible en tout temps. Le prix ne change pas dans 24 heures. Il n'y a pas de "seulement 3 places restantes."

Ce que je te dis par contre, c'est que plus longtemps l'organisation reste sans ces fondations-là, plus longtemps Google et les IA la comprennent pas. Et chaque mois qui passe sans contenu bien structuré, c'est un mois de plus à laisser du trafic qualifié sur la table.

Si t'es pas prête ou prêt aujourd'hui, c'est correct. Garde le Bilan SEO quelque part. Reviens-y quand le timing est bon.

Si tu es prête ou prêt : → [Le Baluchon SEO IA, 26 $](genevievebergeron.ca/baluchon)

À bientôt,
Geneviève

*P.S. Je continue d'envoyer du contenu utile sur le SEO et les IA de temps en temps — sans te spammer. Tu peux rester abonnée ou abonné même si Le Baluchon n'est pas pour toi maintenant.*

---
---

## SÉQUENCE B — POST-ACHAT : BALUCHON SEUL (sans Escouade)
*7 courriels · Déclencheur : achat du Baluchon (sans order bump)*

---

### B1 — IMMÉDIAT · Bienvenue + accès

**Objet :** Bienvenue dans Le Baluchon — ton accès est là

**Pré-header :** Par où commencer (c'est écrit dedans, mais voici le raccourci).

---

Salut,

Ton accès au Baluchon SEO IA est confirmé.

→ [Accéder à la formation](lien-systeme-io)
→ [Télécharger La Pieuvre (Google Sheets)](lien-sheets)
→ [Accéder à l'assistant Le Radar](lien-poe-ou-claude)
→ [Télécharger le guide PDF Rédaction Magnétique](lien-pdf)

**Par où commencer?**

Vidéo 1 d'abord. Elle dure 8 minutes et te permet d'identifier tes 3 pages piliers avant de faire quoi que ce soit d'autre. Sauter cette étape et aller directement dans l'optimisation = travailler sur les mauvaises pages.

Ensuite : Vidéo 2 + L'assistant Le Radar. Tu vas avoir tes 3 batailles SEO à la fin de la session.

Reste dans cet ordre. C'est fait exprès.

Si tu bloques sur quelque chose, réponds à ce courriel.

Geneviève

*P.S. Si tu veux sauver 8 à 10 heures de travail sur les 5 prochains jours, L'Escouade IA est encore disponible en ajout : deux assistants IA configurés pour faire la structure et la rédaction à ta place. → [Ajouter L'Escouade (19 $)](lien-order-bump)*

---

### B2 — J+1 · Conseil pour bien utiliser Le Radar

**Objet :** Le Radar : comment lui parler pour avoir de vraies réponses

**Pré-header :** Un brief vague = des résultats vagues. Voici comment éviter ça.

---

Salut,

Journée 2 — normalement, tu commences avec L'assistant Le Radar aujourd'hui (Vidéo 2).

Un conseil avant que tu ouvres l'assistant :

**La qualité du brief que tu lui donnes détermine la qualité de ses recommandations.**

Ce qu'il te faut pour un bon brief :
- Le nom et le secteur de l'organisation (sois précise — pas "communications" mais "organisme de développement économique local")
- La ville et le quartier où l'organisation opère principalement
- Le service ou programme qui génère le plus de demandes ou de revenus
- La clientèle principale en une phrase précise

Ce que tu évites : copier-coller toute la page À propos. Le Radar a besoin d'un point focal, pas d'un roman.

Si les premières recommandations sont trop génériques, reformule le brief en précisant davantage le territoire ou la spécialité. C'est normal — c'est un dialogue, pas un oracle.

Bonne journée d'analyse,
Geneviève

---

### B3 — J+2 · Rappel La Pieuvre

**Objet :** La Pieuvre : une habitude qui vaut son pesant de résultats

**Pré-header :** Ouvre-la avant de toucher une page. Ferme-la après chaque session.

---

Salut,

Journée 3 — normalement, tu commences à entrer tes 3 batailles dans La Pieuvre et à auditer tes pages.

Une règle simple pour bien utiliser La Pieuvre :

**Ouvre-la avant de toucher une page. Ferme-la après chaque session.**

C'est pas compliqué, mais si tu l'ouvres seulement quand tu penses y penser — elle devient juste un fichier de plus dans ton Drive.

La Pieuvre est efficace parce qu'elle centralise des décisions qui autrement se perdent dans des notes, des courriels et des Post-it. Si tu documentes tes changements dedans *au moment* où tu les fais, dans 30 jours tu vas pouvoir voir exactement ce qui a changé et mesurer l'impact.

C'est ce que tu vas présenter à ta direction dans les prochains bilans.

Geneviève

---

### B4 — J+4 · Conseil rédaction magnétique

**Objet :** La règle d'or de la rédaction SEO (et elle est contre-intuitive)

**Pré-header :** Moins de pronoms = plus de visibilité. Explications.

---

Salut,

Journée 4 ou 5 — tu es en mode rédaction.

La règle la plus contre-intuitive de la rédaction SEO : **remplace les pronoms par des entités.**

Exemple :

*Avant :* "Notre équipe l'aide à améliorer sa visibilité grâce à notre approche unique."

*Après :* "Les PME et OBNL québécois améliorent leur visibilité organique grâce à une stratégie SEO adaptée au marché francophone local."

Pourquoi? Google et les IA lisent les entités (noms précis, lieux, concepts) pour comprendre de quoi parle une page. Les pronoms sont flous. "Notre équipe" pourrait s'appliquer à n'importe qui. "Les PME et OBNL québécois" + "stratégie SEO" + "marché francophone local" = des entités que Google peut indexer et associer à des recherches précises.

C'est pas une question de style. C'est une question de signal.

Geneviève

---

### B5 — J+6 · Check-in + intro douce Escouade (si pas achetée)

**Objet :** À mi-chemin — comment ça se passe?

**Pré-header :** Et si tu sens que la rédaction prend trop de temps, il y a une raison.

---

Salut,

Tu es normalement au milieu de la semaine d'exécution. Comment ça se passe?

Si la rédaction et la restructuration des pages prennent plus de temps que prévu, c'est complètement normal. C'est la partie la plus longue du processus.

C'est pourquoi j'avais prévu L'Escouade IA comme complément au Baluchon : deux assistants configurés spécifiquement pour faire ce travail à ta place. Le Bâtisseur sort la structure H1-H3 et les meta en quelques minutes. Le Coach nettoie le texte et insère le bloc FAQ optimisé pour les IA.

Si tu l'as pas encore ajouté et que tu veux sauver du temps sur les pages 2 et 3 :
→ [Ajouter L'Escouade IA (19 $)](lien)

Si tu avances bien sans : parfait, continue. C'est fait pour être faisable sans.

Geneviève

---

### B6 — J+10 · Introduction à La Vigie

**Objet :** Tes pages sont publiées. Et maintenant?

**Pré-header :** Le SEO, ça se mesure. Voici comment faire ça correctement.

---

Salut,

Si tu as suivi le plan, tes 3 pages piliers sont publiées ou en cours de publication. Bravo.

Maintenant, il faut savoir si ça fonctionne.

Le SEO prend 4 à 12 semaines pour se refléter dans les classements Google — c'est la réalité du SEO organique. Ce que tu peux faire pendant ce temps : configurer le suivi et préparer les données.

Dans 30 jours, tu vas vouloir regarder Google Search Console et répondre à ces questions :
- Est-ce que mes 3 pages sont mieux positionnées pour les mots-clés ciblés?
- Est-ce que le CTR a amélioré?
- Est-ce que ChatGPT ou Perplexity me citent maintenant?

Si tu veux un système pour répondre à ces questions sans passer des heures dans des dashboards :

→ **La Vigie SEO — 47 $**
L'assistant IA L'Analyste + Dashboard Google Sheets 12 mois + Masterclass "L'Écho de l'IA"

C'est l'étape d'après. Pas obligatoire maintenant — mais utile avant que les 30 premiers jours passent sans données.

Geneviève

---

### B7 — J+21 · Graine mid-ticket

**Objet :** Un mois plus tard — qu'est-ce que tu vois dans Search Console?

**Pré-header :** Si tu as des données, voici quoi en faire.

---

Salut,

Ça fait environ 3 semaines. Normalement, les premières données commencent à apparaître dans Google Search Console.

Si tu vois des positions qui bougent pour tes mots-clés cibles : c'est que la méthode fonctionne. Continue dans cette direction.

Si tu vois pas encore grand chose : c'est normal pour des pages dans des secteurs moyennement compétitifs. La patience est une compétence SEO.

Si tu te demandes "est-ce que j'aurais besoin qu'on regarde ça ensemble" : oui, c'est exactement ce que je fais dans l'Audit Deep Dive.

L'Audit Deep Dive, c'est une analyse complète de ton écosystème numérique : bilinguisme, UX, SEO technique profond, cohérence de l'architecture de contenu. On sort de là avec un plan priorisé et un regard externe sur ce que les outils automatisés ne peuvent pas voir.

C'est une offre à 800 $. C'est pas le Baluchon — c'est l'étape d'après pour les organisations qui veulent aller plus loin.

Si ça t'intéresse, réponds à ce courriel avec "Audit" et je t'envoie les détails.

Geneviève

---
---

## SÉQUENCE C — POST-ACHAT : BALUCHON + ESCOUADE (order bump coché)
*5 courriels · Déclencheur : achat du Baluchon avec L'Escouade*

---

### C1 — IMMÉDIAT · Bienvenue avec accès complet

**Objet :** Tout est là — Baluchon + Escouade, mode complet activé

**Pré-header :** 4 outils, 2 assistants IA, un plan sur 5 jours. Voici comment s'y retrouver.

---

Salut,

Ton accès complet est confirmé. Voici tout ce que tu as :

**Le Baluchon SEO IA**
→ [5 micro-vidéos](lien)
→ [La Pieuvre — Google Sheets](lien)
→ [Assistant Le Radar](lien)
→ [Guide PDF Rédaction Magnétique](lien)

**L'Escouade IA**
→ [Assistant Le Bâtisseur](lien)
→ [Assistant Le Coach](lien)
→ [Checklist Lighthouse au Vert](lien)

**L'ordre recommandé :**
Jour 1 : Vidéo 1 → identifier les 3 pages piliers
Jour 2 : Vidéo 2 → Le Radar → 3 batailles + URL → La Pieuvre
Jour 3 : Page 1 → Vidéo 4 → Le Bâtisseur → Le Coach → publie
Jour 4 : Page 2 → même processus
Jour 5 : Page 3 + vérification Lighthouse

**Le Bâtisseur et Le Coach, ça s'utilise comment?**
C'est dans les instructions incluses avec chaque assistant. Lecture de 5 minutes, ensuite c'est un copier-coller.

Questions? Je suis là.
Geneviève

---

### C2 — J+1 · Comment bien alimenter Le Radar

*(Identique au B2 — même conseil, même logique)*

---

### C3 — J+2 · Activer Le Bâtisseur sur la première page

**Objet :** Le Bâtisseur : ce que tu lui donnes, ce qu'il te retourne

**Pré-header :** Copier-coller ton texte de page. Recevoir une structure H1-H3 prête à utiliser.

---

Salut,

Journée 3 — normalement, tu travailles sur ta première page pilier.

Voici comment utiliser Le Bâtisseur efficacement :

**Ce que tu lui donnes :** le texte brut de ta page (tout ce qui est dessus aujourd'hui, même si c'est imparfait). Pas besoin de le nettoyer avant — c'est son travail.

**Ce qu'il te retourne :**
- Un H1 révisé (titre principal optimisé pour le mot-clé cible)
- Les sous-titres H2 et H3 dans un ordre logique
- Une meta description de 150 à 160 caractères
- Des suggestions de texte ALT pour les images principales

**Ce que tu fais avec ça :** tu copies, tu colles dans ton CMS (WordPress, Wix, Squarespace, etc.), tu ajustes si quelque chose sonne pas comme toi, tu publies.

Le Bâtisseur ne génère pas de texte de zéro. Il restructure ce que tu as déjà. La voix de ton organisation reste la tienne.

Geneviève

---

### C4 — J+4 · Le Coach — l'étape qui fait vraiment la différence

**Objet :** Le Coach : l'assistant qui fait le travail que tout le monde remet à plus tard

**Pré-header :** Le bloc FAQ optimisé pour les IA. C'est là que beaucoup de gens s'arrêtent — et où les résultats se jouent.

---

Salut,

Le Coach, c'est l'assistant que les gens utilisent en dernier — et qui fait souvent la plus grosse différence.

Son travail : prendre le texte que tu lui donnes et le rendre plus dense, plus précis, plus lisible pour les IA génératives.

Concrètement, Le Coach :
- Retire les formulations floues ("notre équipe" → le nom de l'organisation ou de la profession)
- Remplace les pronoms par des entités précises
- Reformule les phrases passives en actives
- Insère un bloc FAQ à la fin de la page, structuré pour être facilement citable par ChatGPT et Perplexity

**Le bloc FAQ, c'est quoi exactement?**
3 à 5 questions que tes clients posent vraiment, avec des réponses précises de 2 à 3 phrases. Format direct, pas de jargon. Les IA adorent ça parce que c'est facile à extraire et à citer.

Si ta page n'a pas de FAQ aujourd'hui : Le Coach en génère un à partir du texte de ta page. Tu révises, tu ajustes, tu publies.

Geneviève

---

### C5 — J+6 · Introduction La Vigie + graine mid-ticket

**Objet :** Tes 3 pages sont publiées. La prochaine étape, c'est quoi?

*(Même logique que B6 + B7 combinés, légèrement adapté pour quelqu'un qui a aussi L'Escouade)*

---

Salut,

Si tout s'est passé selon le plan, tes 3 pages piliers sont publiées et structurées correctement — avec la hiérarchie H1-H3, les meta descriptions, les blocs FAQ et les balises ALT.

C'est un beau travail.

Maintenant : le SEO prend 4 à 12 semaines pour se refléter. Ce que tu peux faire pendant ce temps, c'est configurer le suivi pour ne pas rater les premières données quand elles arrivent.

La Vigie SEO t'offre ça : L'assistant IA L'Analyste pour décoder tes données Search Console, un Dashboard de performance sur 12 mois, et la Masterclass "L'Écho de l'IA" pour vérifier si ChatGPT parle de ton organisation.

→ [Ajouter La Vigie SEO (47 $)](lien)

Et si dans 30 à 60 jours tu veux un regard externe sur l'ensemble de ton écosystème numérique : c'est l'Audit Deep Dive. Réponds à ce courriel avec "Audit" et je t'envoie les détails.

Geneviève
