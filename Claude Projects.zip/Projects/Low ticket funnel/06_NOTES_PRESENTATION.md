# 📝 NOTES DE PRÉSENTATION — Le Baluchon SEO IA
**À copier-coller dans le panneau "Notes" de chaque diapositive Canva**
*(Mode édition → icône Notes en bas de l'écran, ou View → Presenter notes)*

---

## DIAPO 1 — Le Baluchon SEO IA *(Titre)*

Bienvenue dans la formation Le Baluchon SEO IA. Je m'appelle Geneviève Bergeron — je suis consultante en marketing numérique à Montréal, spécialisée en SEO et stratégie IA pour les PME et OBNL québécois.

Dans les 5 modules qui suivent, on ne théorise pas. On opère. À la fin de cette formation, tu auras 3 pages piliers optimisées pour Google ET les moteurs IA — ChatGPT, Perplexity, AI Overviews. En 5 jours. Sans agence. Sans jargon.

Voici ce qu'on va faire ensemble.

---

## DIAPO 2 — Ce que tu vas accomplir

La promesse de cette formation, c'est pas floue : 3 pages piliers, 5 jours, une visibilité béton.

Pas pour tout le site. Pas 50 pages à optimiser. 3 pages qui représentent 80 % de ton levier SEO. Google va les voir. Et si on fait bien les choses — ChatGPT et Perplexity vont en parler aussi.

Sans expertise technique. Sans abonnement à des outils à 200 $/mois. Avec ce que t'as dans le Baluchon.

---

## DIAPO 3 — Comment naviguer la formation

La formation se découpe en 5 modules — 5 vidéos de 8 à 12 minutes chacune. Rythme suggéré : 45 à 90 minutes par jour pendant 5 jours.

Tes 3 outils principaux :
→ **Le Radar** : l'agent IA qui analyse ton marché québécois
→ **La Pieuvre** : le fichier Google Sheets qui centralise tout
→ **Le Guide Rédaction Magnétique** : les règles d'écriture pour plaire à Google ET aux IA

Garde ces outils ouverts pendant que tu regardes les vidéos. C'est une formation d'exécution, pas de consommation.

---

## DIAPO 4 — MODULE 1 : Pourquoi 3 pages (et pas 50)

Transition de module. Prendre un instant. Laisser l'image parler.

Point de contact avec la salle : "Combien de pages avez-vous sur votre site en ce moment ? Combien Google en indexe vraiment ?"

La plupart des PME québécoises ont des dizaines de pages. Google en indexe peut-être 5. Les clients en lisent 3. C'est là qu'on commence.

---

## DIAPO 5 — Le levier : 3 pages = 80 % des résultats

Le SEO, c'est du capital. Tu répares pas ton toit partout en même temps — tu commences là où il pleut.

**3 critères pour choisir une page pilier :**
1. Directement liée à une source de revenus ou à la mission
2. Une intention de recherche réelle existe — des gens cherchent ça
3. La concurrence est réaliste — pas en guerre contre un géant national

**L'exercice mental :** "Si cette page disparaissait demain, est-ce que ça coûterait de l'argent ou des donateurs à l'organisation ?" → Si oui : c'est une candidate.

**Ce qui N'est PAS une page pilier :** page d'accueil générique, page À propos trop vague, article de blogue sur les tendances.

Une page bien optimisée > dix pages moyennes. Le SEO bien fait est un actif qui travaille 12, 24, 36 mois.

---

## DIAPO 6 — MODULE 2 : L'agent IA Le Radar

Transition de module.

La recherche de mots-clés, ça fait peur. Y'a des outils à 200 $/mois. Des tableaux compliqués. Des experts qui parlent en chiffres.

La réalité pour une PME ou un OBNL : on a besoin de 3 mots-clés stratégiques — pas d'un rapport de 50 pages. Le Radar fait exactement ça.

**Important :** Le Radar est un éditeur, pas un générateur. On lui donne le contexte de l'organisation, il travaille AVEC cet input. Garbage in, garbage out.

---

## DIAPO 7 — Ce que fait Le Radar — 3 outputs

**Comment utiliser Le Radar (4 étapes, 20 minutes) :**

1. Ouvrir l'agent Le Radar (lien dans ton accès formation)
2. Rédiger le brief : nom de l'organisation + secteur + ville/région + clientèle principale + service le plus important
3. Lancer l'analyse
4. Lire les résultats : 3 mots-clés stratégiques + justification + structure d'URL recommandée

**Ce que Le Radar retourne :**
→ Analyse du marché local québécois (il connaît la différence entre Villeray et le Plateau)
→ 3 batailles SEO réalistes selon la taille et la niche
→ Une structure d'URL stratégique pour chaque page

**Ce qu'on fait avec les résultats :** on les colle directement dans l'Onglet 1 de La Pieuvre. C'est la prochaine vidéo.

---

## DIAPO 8 — MODULE 3 : La Pieuvre, ton quartier général

Transition de module.

Problème classique : les décisions SEO se perdent dans des notes Notion, des PDF, des courriels. On travaille pendant 3 heures, on ferme l'ordinateur, et 3 semaines plus tard on recommence à zéro.

La Pieuvre règle ça. Un seul fichier = une seule vérité. Règle d'or : ouvrir La Pieuvre avant de toucher à une page. Fermer La Pieuvre après chaque session.

---

## DIAPO 9 — Les 3 onglets de La Pieuvre

**Onglet 1 — Les 3 Batailles :**
Mots-clés, URL, intention de recherche, statut (À faire / En cours / Publié). Tu colles les outputs du Radar ici.

**Onglet 2 — L'Optimisation par page :**
H1 actuel / H1 suggéré, meta description, balises ALT images, présence d'un FAQ. On diagnostique AVANT de rédiger — jamais de rédaction dans le vide.

**Onglet 3 — Le Suivi de performance :**
Date de publication, position Google (Search Console), clics, impressions. On remplit ça à J+30, J+60, J+90. Pas aujourd'hui — dans 30 jours.

10 minutes par mois. C'est tout ce que ça prend pour suivre ses progrès.

---

## DIAPO 10 — MODULE 4 : Rédaction Magnétique

Transition de module.

Le mythe à démolir : "écrire pour le SEO = texte robotique bourré de mots-clés." Faux. En 2025, Google et les IA valorisent les textes denses, clairs, avec des entités sémantiques riches.

Ce que la méthode apporte : une façon d'écrire qui plaît aux algos ET qui ressemble à l'organisation. Pas une traduction de l'anglais. Pas du contenu générique. Du québécois authentique qui fait ranker.

4 règles. On y va.

---

## DIAPO 11 — Les 4 règles + la structure H1-H3

**Règle 1 — Entités sémantiques :**
Une entité = un nom précis que Google reconnaît. "Comptable" est un mot. "CPA auditeur Sherbrooke" est une entité.
→ Avant : "Notre équipe aide les clients à gérer leurs finances"
→ Après : "Les CPA de la firme XYZ accompagnent les PME manufacturières sherbrookoises dans la gestion de trésorerie et la planification fiscale"

**Règle 2 — Écriture épicène, Zéro Pronom :**
Dense, fonctionnelle, sans pronoms flous. Relire chaque phrase : si un pronom peut être remplacé par un nom précis, le remplacer.

**Règle 3 — Localisation micro :**
Pas "Montréal" — "Rosemont", "Plateau-Mont-Royal", "Villeray". Les recherches locales précises sont moins concurrentielles ET plus intentionnelles.

**Règle 4 — Bloc FAQ pour les IA :**
3 à 5 questions que les clients posent vraiment. Réponses de 2-3 phrases. Entités sémantiques dans chaque réponse. C'est là que ChatGPT et Perplexity viennent chercher leurs citations.

**Structure H1-H3 :**
H1 = promesse principale + mot-clé prioritaire
H2 = sections thématiques (entités sémantiques)
H3 = sous-sections + questions FAQ
Meta = 150-160 caractères actionnables

---

## DIAPO 12 — MODULE 5 : Le plan d'exécution 5 jours

Transition de module.

Récapitulatif du chemin parcouru : 3 pages identifiées, Le Radar a confirmé les batailles, La Pieuvre est configurée, les règles de rédaction sont claires.

Ce qui reste : l'exécution. C'est là que la plupart abandonnent. La solution : un plan précis, jour par jour. Pas d'improvisation.

---

## DIAPO 13 — Les 5 jours en un coup d'œil

**Jour 1 — Diagnostic (60-75 min) :**
Ouvrir La Pieuvre → auditer les 3 pages existantes (H1, meta, FAQ présent ou non, entités) → lancer Le Radar → coller les résultats dans l'Onglet 1. On ne rédige RIEN aujourd'hui.

**Jour 2 — Page pilier #1 (75-90 min) :**
Focus sur UNE page seulement. Réécrire le H1, la meta, le premier paragraphe. Vérifier les entités. Ajouter ou améliorer le FAQ. Publier.

**Jour 3 — Page pilier #2 (75-90 min) :**
Même protocole. Si tu as l'Escouade IA : utiliser Le Bâtisseur pour accélérer la structure H1-H3.

**Jour 4 — Page pilier #3 (75-90 min) :**
Même protocole. Le Coach (Escouade) peut nettoyer le texte et supprimer les pronoms flous en quelques minutes.

**Jour 5 — Révision technique (30-45 min) :**
Vérifier les 3 pages : H1 correspond au mot-clé cible? Meta complète? Balises ALT sur toutes les images? Score Lighthouse. Publier les dernières corrections. Configurer l'Onglet 3 de La Pieuvre. Résultat : 3 pages piliers publiées et prêtes à ranker.

---

## DIAPO 14 — Ce que tu as dans ton Baluchon

Récapitulatif de tout ce qui est inclus dans l'accès :

→ **Le Radar** : agent IA, analyse de marché québécois, 3 batailles SEO
→ **La Pieuvre** : Google Sheets, quartier général SEO sur 12 mois
→ **Rédaction Magnétique** : guide PDF, règles + exemples sectoriels québécois
→ **5 vidéos** : 8-12 min chacune, accès à vie
→ **Si tu as l'Escouade IA (+19 $)** : Le Bâtisseur (H1-H3, meta, ALT automatiques) + Le Coach (nettoyage rédactionnel + FAQ GEO) = 8 à 10 heures économisées sur les 5 jours

Résultats mesurables : 4 à 12 semaines selon la compétitivité du secteur. Ce qui accélère : cohérence des entités sur tout le site, liens internes vers les pages piliers, vitesse du site.

Prochaine étape naturelle : La Vigie SEO (47 $) pour le suivi analytique sur 12 mois.

---

## DIAPO 15 — Tu as tout ce qu'il faut. Go.

Ton organisation fait du bon travail. Il est temps que Google le sache. Et que ChatGPT en parle.

Tu as la méthode. Tu as les outils. Tu as le plan jour par jour.

La seule chose qui reste, c'est de commencer. Ouvre La Pieuvre. Lance Le Radar. Écris la première ligne de ton H1 optimisé.

Des questions? bonsoir@genevievebergeron.ca

Pour aller plus loin :
→ L'Audit Deep Dive (800 $) — j'analyse ton écosystème complet
→ L'Accompagnement 360 (2 500 $+) — on prend les clés ensemble

---

*💡 Pour coller ces notes dans Canva : ouvre ta présentation en mode édition → clique sur une diapositive → clique sur l'icône Notes (📝) en bas de l'écran → colle le texte correspondant.*
