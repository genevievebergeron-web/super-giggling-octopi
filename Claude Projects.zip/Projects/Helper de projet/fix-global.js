/* ============================================================
   fix-global.js
   \u00c0 inclure sur TOUTES les pages du site genevievebergeron.ca
   Corrections : curseur personnalis\u00e9 + liens mailto: pr\u00e9-remplis
   ============================================================ */

(function () {
  'use strict';

  /* ─── 1. CURSEUR PERSONNALIS\u00c9 ─── */
  document.addEventListener('DOMContentLoaded', function () {

    // S\u2019assurer que l\u2019\u00e9l\u00e9ment curseur est bien un enfant direct du body
    let cursor = document.querySelector('.cursor');
    if (!cursor) {
      cursor = document.createElement('div');
      cursor.className = 'cursor';
      document.body.appendChild(cursor);
    } else if (cursor.parentElement !== document.body) {
      document.body.appendChild(cursor);
    }

    // Suivi de la souris \u2014 attacher au document (couvre TOUT, y compris le header et les dropdowns)
    document.addEventListener('mousemove', function (e) {
      cursor.style.left = e.clientX + 'px';
      cursor.style.top  = e.clientY + 'px';
    });

    // Effet hover sur \u00e9l\u00e9ments interactifs
    function addHoverListeners() {
      document.querySelectorAll('a, button, [onclick], label, input, select, textarea').forEach(function (el) {
        el.addEventListener('mouseenter', function () {
          cursor.classList.add('hover');
        });
        el.addEventListener('mouseleave', function () {
          cursor.classList.remove('hover');
        });
      });
    }
    addHoverListeners();

    // Correction sp\u00e9cifique au nav dropdown :
    // Quand la souris entre dans le dropdown, s\u2019assurer que le curseur reste visible
    // en passant temporairement le mix-blend-mode \u00e0 'normal'
    const navDropdowns = document.querySelectorAll('.nav-dropdown');
    navDropdowns.forEach(function (dropdown) {
      dropdown.addEventListener('mouseenter', function () {
        cursor.style.mixBlendMode = 'normal';
        cursor.style.background   = 'var(--amber, #D4900A)';
      });
      dropdown.addEventListener('mouseleave', function () {
        cursor.style.mixBlendMode = 'difference';
        cursor.style.background   = 'var(--cream, #F5F0E8)';
      });
    });

    // Observer les changements DOM pour les \u00e9l\u00e9ments ajout\u00e9s dynamiquement (ex: quiz)
    const observer = new MutationObserver(function () {
      addHoverListeners();
    });
    observer.observe(document.body, { childList: true, subtree: true });

    // Masquer/montrer le curseur quand la souris quitte la fen\u00eatre
    document.addEventListener('mouseleave', function () {
      cursor.style.opacity = '0';
    });
    document.addEventListener('mouseenter', function () {
      cursor.style.opacity = '1';
    });
  });

  /* ─── 2. LIENS MAILTO: AVEC SUJET PR\u00c9-REMPLI ─── */
  document.addEventListener('DOMContentLoaded', function () {

    const SUJET_PAR_DEFAUT = encodeURIComponent('Demande de projet \u2014 Genevi\u00e8ve Bergeron');

    // Mettre \u00e0 jour tous les liens mailto: existants pour ajouter le sujet s\u2019il est absent
    document.querySelectorAll('a[href^="mailto:"]').forEach(function (link) {
      const href = link.getAttribute('href');
      if (!href.includes('?subject') && !href.includes('&subject')) {
        link.setAttribute('href', href + '?subject=' + SUJET_PAR_DEFAUT);
      }
    });

    // Mettre \u00e0 jour le lien affich\u00e9 de l\u2019adresse courriel si pr\u00e9sent
    document.querySelectorAll('a[href*="bonjour@genevievebergeron.ca"]').forEach(function (link) {
      const href = link.getAttribute('href');
      if (!href.includes('subject=')) {
        link.setAttribute('href', 'mailto:bonjour@genevievebergeron.ca?subject=' + SUJET_PAR_DEFAUT);
      }
    });
  });

})();
