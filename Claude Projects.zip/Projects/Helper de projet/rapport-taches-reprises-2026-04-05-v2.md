# Rapport — Passe automatique du 5 avril 2026 (v2)
*Tâches interrompues des dernières 24h — Bilan de session · ~03h00*

---

## ✅ Tâche complétée dans cette passe

### Page `services/ecoconception/index.html` — CRÉÉE ET AJOUTÉE AU ZIP

La tâche était bloquée depuis plusieurs passes consécutives. Cette passe l'a complétée de façon autonome.

**Ce qui a été fait :**
- Création complète de `services/ecoconception/index.html` fidèle au template du site (couleurs, typographies, curseur custom, nav, footer)
- Contenu original et cohérent avec la marque Octopus Marketing Numérique :
  - Hero avec stats (4% des émissions mondiales, ~2g CO₂/visite, +28% conversion)
  - Simulateur d'audit interactif (estimation de l'empreinte carbone avec résultats visuels)
  - Section 3 piliers (Performance, Design minimaliste, Hébergement responsable)
  - Processus en 4 étapes cliquables
  - FAQ (5 questions couvrant coût, SEO, CMS compatibles, OBNL)
  - Liens vers les 4 autres services
- ZIP `site-v2-genevievebergeron.zip` mis à jour — la page est maintenant incluse

**Hypothèses faites :**
- Les calculateurs référencés sont EcoIndex et Website Carbon Calculator (outils standards du domaine)
- Le simulateur est une estimation locale (pas d'appel API externe) — mentionné clairement dans l'interface
- Le tarif OBNL est mentionné mais non précisé (renvoi vers prise de contact)
- La page n'a PAS encore été ajoutée au menu dropdown des 4 autres pages de services (modif qui nécessiterait une décision de Geneviève sur la structure du menu)

---

## 🟡 Sessions encore actives (en cours au moment du rapport)

### 1. "Background site web" (vigilant-admiring-mayer)
**Statut :** 🟡 En cours — corrige les slides 11, 13 et 14 de la présentation Baluchon via API Canva
- Laisse compléter — ne pas interrompre

### 2. "Background ltf" (eloquent-practical-lovelace)
**Statut :** 🟡 En cours — vérification finale du site V2 / recherche Google Drive
- A confirmé que slide 15 est vide (0 élément texte) — l'API ne peut pas créer de nouveaux éléments
- Laisse compléter

---

## ⚠️ Actions manuelles toujours en attente

### 1. Slide 15 de la présentation Baluchon — BLOQUÉE (API Canva)
La slide est visuellement vide. L'API Canva ne peut que modifier des éléments existants, pas en créer de nouveaux. Il faut aller directement dans Canva.

**Ouvrir :** https://www.canva.com/d/NrU3sHCTvsXwG2K

Contenu à copier-coller pour la slide 15 (slide de fermeture / CTA) :

**Titre :**
> Ton organisation fait du bon travail.
> Il est temps que Google le sache. Et que ChatGPT en parle.

**Sous-titre :**
> Tu as la méthode. Tu as les outils. Tu as le plan jour par jour.
> La seule chose qui reste, c'est de commencer.

**Contact :**
> Des questions ? bonjour@genevievebergeron.ca

**Pour aller plus loin :**
> → L'Audit Deep Dive (800 $) — j'analyse ton écosystème complet
> → L'Accompagnement 360 (2 500 $+) — on prend les clés ensemble

---

### 2. Menu dropdown des pages de services — À valider
La nouvelle page écoconception n'a pas été ajoutée au menu dropdown des 4 autres pages de services existantes (referencement-naturel, contenu-editorial, design-graphique, automatisations-ia). Le dropdown de ces pages montre encore 4 services.

**Options :**
- Si tu veux l'ajouter : signaler à la prochaine session, ça se fait en 5 minutes
- La page écoconception elle-même a son menu à jour (5 services dans son dropdown)

---

## 📋 ZIP — État final

| Fichier | Présent |
|---|---|
| `index.html` | ✅ |
| `a-propos/index.html` | ✅ |
| `services/index.html` | ✅ |
| `services/referencement-naturel/index.html` | ✅ |
| `services/contenu-editorial/index.html` | ✅ |
| `services/design-graphique/index.html` | ✅ |
| `services/automatisations-ia/index.html` | ✅ |
| `services/ecoconception/index.html` | ✅ **NOUVEAU** |
| Emails corrigés (bonjour@) | ✅ |
| Curseur CSS / fix-global.js | ✅ |

---

## 📋 Résumé des actions à prendre (par priorité)

1. **🔴 Compléter slide 15 manuellement dans Canva** → https://www.canva.com/d/NrU3sHCTvsXwG2K
2. **🟡 Valider la page écoconception** → Ouvrir le ZIP et vérifier que le contenu convient
3. **🟡 Décider si le menu des autres pages doit être mis à jour** → Mentionner à la prochaine session
