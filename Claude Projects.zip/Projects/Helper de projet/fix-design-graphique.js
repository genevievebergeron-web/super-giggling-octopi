/* ============================================================
   fix-design-graphique.js
   Page : /services/design-graphique/
   Fonctions manquantes : pick, nextQ, resetQ,
                          setEco, setWeb, toggleFlow, toggleFaq
   ============================================================ */

(function () {
  'use strict';

  /* ─── QUIZ ─── */
  const QUESTIONS = [
    {
      q: 'Quel est le type de livrable principal\u00a0?',
      opts: [
        'Identit\u00e9 visuelle compl\u00e8te (logo, palette, typographie)',
        'Support imprim\u00e9 (affiche, d\u00e9pliant, carte professionnelle)',
        'Habillage v\u00e9hicule ou signal\u00e9tique ext\u00e9rieure',
        'Visuels num\u00e9riques (r\u00e9seaux, banni\u00e8res, pochette de disque)'
      ]
    },
    {
      q: 'O\u00f9 en \u00eates-vous dans votre projet\u00a0?',
      opts: [
        'Je pars de z\u00e9ro \u2014 tout est \u00e0 cr\u00e9er',
        "J\u2019ai une identit\u00e9 existante \u00e0 moderniser",
        "J\u2019ai des \u00e9l\u00e9ments \u00e9pars \u00e0 unifier",
        "Je cherche un regard ext\u00e9rieur sur mon image actuelle"
      ]
    },
    {
      q: 'Quel est votre horizon de livraison id\u00e9al\u00a0?',
      opts: [
        'Moins d\u2019un mois \u2014 c\u2019est urgent',
        '1 \u00e0 2 mois \u2014 d\u00e9lai standard',
        '2 \u00e0 3 mois \u2014 je veux prendre le temps',
        'Pas encore d\u00e9fini \u2014 encore en exploration'
      ]
    }
  ];

  const RESULTS = [
    {
      title: 'Forfait Identit\u00e9 compl\u00e8te',
      text: "Vous avez besoin d\u2019une identit\u00e9 strat\u00e9gique et coh\u00e9rente\u00a0: brief visuel, logo, palette, typographie et guide d\u2019utilisation. Dur\u00e9e typique\u00a0: 3 \u00e0 6 semaines selon la complexit\u00e9.",
      cta: 'Discuter de mon identit\u00e9'
    },
    {
      title: 'Production graphique cibl\u00e9e',
      text: 'Design et mise en page de votre support, optimis\u00e9 pour l\u2019impression ou la diffusion num\u00e9rique. Livraison des fichiers pr\u00eats pour l\u2019imprimeur. Dur\u00e9e typique\u00a0: 1 \u00e0 3 semaines.',
      cta: 'Lancer ma production'
    },
    {
      title: 'Design grand format & signal\u00e9tique',
      text: 'Conception adapt\u00e9e aux contraintes du grand format (v\u00e9hicule, affichage ext\u00e9rieur), avec livrables pr\u00eats pour votre imprimeur. Dur\u00e9e typique\u00a0: 2 \u00e0 4 semaines.',
      cta: 'D\u00e9marrer mon projet signal\u00e9tique'
    },
    {
      title: 'Gabarits visuels num\u00e9riques',
      text: 'Conception d\u2019une s\u00e9rie de gabarits coh\u00e9rents pour vos r\u00e9seaux sociaux ou banni\u00e8res web \u2014 faciles \u00e0 adapter vous-m\u00eame. Dur\u00e9e typique\u00a0: 1 \u00e0 2 semaines.',
      cta: 'Cr\u00e9er mes gabarits'
    }
  ];

  let currentQ = 0;
  let answers  = [];

  function renderQ(index) {
    const step  = document.getElementById('qstep');
    const qq    = document.getElementById('qq');
    const qopts = document.getElementById('qopts');
    const qbar  = document.getElementById('qbar');
    const qres  = document.getElementById('qres');
    const qnext = document.getElementById('qnext');

    if (!step) return;

    const data = QUESTIONS[index];
    step.textContent  = 'Question ' + (index + 1) + ' sur ' + QUESTIONS.length;
    qq.textContent    = data.q;
    qbar.style.width  = (((index) / QUESTIONS.length) * 100) + '%';
    qres.style.display = 'none';
    if (qnext) qnext.style.display = 'none';

    qopts.innerHTML = data.opts.map(function (opt, i) {
      return '<button class="quiz-opt" onclick="pick(this,' + i + ')">' + opt + '</button>';
    }).join('');
  }

  window.pick = function (btn, index) {
    answers[currentQ] = index;
    const opts = document.querySelectorAll('.quiz-opt');
    opts.forEach(function (b) { b.classList.remove('selected'); });
    btn.classList.add('selected');

    const qnext = document.getElementById('qnext');
    if (qnext) qnext.style.display = 'inline-flex';
  };

  window.nextQ = function () {
    if (answers[currentQ] === undefined) return;

    currentQ++;
    if (currentQ < QUESTIONS.length) {
      renderQ(currentQ);
    } else {
      showResult();
    }
  };

  window.resetQ = function () {
    currentQ = 0;
    answers  = [];
    renderQ(0);
  };

  function showResult() {
    const resultIndex = answers[0] !== undefined ? answers[0] : 0;
    const res         = RESULTS[resultIndex];
    const qres        = document.getElementById('qres');
    const rtitle      = document.getElementById('rtitle');
    const rtext       = document.getElementById('rtext');
    const raction     = document.getElementById('raction');
    const qopts       = document.getElementById('qopts');
    const qstep       = document.getElementById('qstep');
    const qq          = document.getElementById('qq');
    const qnext       = document.getElementById('qnext');
    const qbar        = document.getElementById('qbar');

    if (!qres) return;

    if (qopts)  qopts.style.display  = 'none';
    if (qstep)  qstep.style.display  = 'none';
    if (qq)     qq.style.display     = 'none';
    if (qnext)  qnext.style.display  = 'none';
    if (qbar)   qbar.style.width     = '100%';

    rtitle.textContent  = res.title;
    rtext.textContent   = res.text;
    raction.innerHTML   =
      '<a href="mailto:bonjour@genevievebergeron.ca?subject=' +
      encodeURIComponent(res.cta) + '" class="btn-amber">' + res.cta + ' \u2192</a>';

    qres.style.display = 'block';
  }

  /* ─── \u00c9CO TABS ─── */
  const ECO_DATA = {
    p\u00e9rennit\u00e9: {
      titre: 'Des fichiers qui durent',
      texte: 'Chaque livrable est nomm\u00e9, structur\u00e9 et document\u00e9 pour rester utilisable dans 5 ans. L\u2019identit\u00e9 con\u00e7ue pour durer plut\u00f4t que pour suivre les tendances de saison.',
      liste: ['\u00c9l\u00e9ments vectoriels r\u00e9utilisables', 'Guide d\u2019utilisation fourni', 'Palettes index\u00e9es pour l\u2019\u00e9cran et l\u2019impression']
    },
    optimisation: {
      titre: 'Moins, mais mieux',
      texte: 'Des palettes r\u00e9duites, des typographies cohérentes, des fichiers l\u00e9gers. Moins de variantes\u00a0= moins de production\u00a0= moins de gaspillage de ressources num\u00e9riques.',
      liste: ['Fichiers SVG et PDF optimis\u00e9s', 'Nombre de couleurs limit\u00e9 et justifi\u00e9', 'Compression sans perte sur tous les exports']
    },
    autonomie: {
      titre: 'Vous \u00eates autonomes apr\u00e8s livraison',
      texte: 'La livraison inclut une formation courte sur l\u2019utilisation de vos fichiers. Vous ne devriez pas avoir besoin de moi pour chaque petite mise \u00e0 jour.',
      liste: ['Documentation claire incluse', 'Fichiers \u00e9ditables fournis', 'Session de transfert de connaissance comprise']
    },
    inclusion: {
      titre: 'Accessible par d\u00e9faut',
      texte: 'Les ratios de contraste WCAG AA sont v\u00e9rifi\u00e9s syst\u00e9matiquement. Les typographies sont lisibles sur tous les supports et pour toutes les personnes.',
      liste: ['Contraste WCAG AA valid\u00e9', 'Polices lisibles et compr\u00e9hensibles', 'Formats universels (PDF, SVG, PNG)']
    }
  };

  window.setEco = function (key, btn) {
    const panel = document.getElementById('eco-panel');
    const tabs  = document.querySelectorAll('.eco-tab');
    if (!panel) return;

    tabs.forEach(function (t) { t.classList.remove('active'); });
    btn.classList.add('active');

    const data = ECO_DATA[key];
    if (!data) return;

    panel.innerHTML =
      '<div class="eco-panel-title">' + data.titre + '</div>' +
      '<p class="eco-panel-text">' + data.texte + '</p>' +
      '<ul class="eco-panel-list">' +
        data.liste.map(function (item) { return '<li>' + item + '</li>'; }).join('') +
      '</ul>';
  };

  /* ─── WEB TABS ─── */
  const WEB_DATA = {
    structure: {
      code: '&lt;header&gt;\n  &lt;nav aria-label="Navigation principale"&gt;\n    &lt;a href="/" class="logo"&gt;Marque&lt;/a&gt;\n    &lt;ul&gt;\n      &lt;li&gt;&lt;a href="/services"&gt;Services&lt;/a&gt;&lt;/li&gt;\n    &lt;/ul&gt;\n  &lt;/nav&gt;\n&lt;/header&gt;\n&lt;main&gt;\n  &lt;article&gt;\n    &lt;h1&gt;Titre principal&lt;/h1&gt;\n    &lt;p&gt;Contenu s\u00e9mantique et structur\u00e9.&lt;/p&gt;\n  &lt;/article&gt;\n&lt;/main&gt;',
      preview: 'HTML s\u00e9mantique \u2014 structure claire pour humains et moteurs de recherche',
      insight: 'Un balisage propre am\u00e9liore autant l\u2019accessibilit\u00e9 que le r\u00e9f\u00e9rencement. C\u2019est la fondation de tout le reste.'
    },
    style: {
      code: ':root {\n  --couleur-primaire: #C94F2C;\n  --couleur-fond: #F5F0E8;\n  --typographie: \'Inter\', sans-serif;\n  --rayon: 4px;\n}\n\n.bouton-principal {\n  background: var(--couleur-primaire);\n  font-family: var(--typographie);\n  border-radius: var(--rayon);\n  padding: 14px 28px;\n}',
      preview: 'Variables CSS \u2014 modifier une valeur, tout change en cascade',
      insight: 'Un syst\u00e8me de variables CSS centralise la charte graphique et r\u00e9duit drastiquement le temps de maintenance.'
    },
    seo: {
      code: '&lt;!-- Balises essentielles --&gt;\n&lt;title&gt;Service | Votre marque&lt;/title&gt;\n&lt;meta name="description" content="150 caract\u00e8res..."&gt;\n\n&lt;!-- Open Graph --&gt;\n&lt;meta property="og:title" content="Titre"&gt;\n&lt;meta property="og:image" content="/og.jpg"&gt;\n\n&lt;!-- Schema.org --&gt;\n&lt;script type="application/ld+json"&gt;\n{ "@type": "LocalBusiness", "name": "..." }\n&lt;/script&gt;',
      preview: 'M\u00e9tadonn\u00e9es compl\u00e8tes \u2014 votre carte de visite dans Google',
      insight: 'Le r\u00e9f\u00e9rencement se pr\u00e9pare dans le code, pas apr\u00e8s la mise en ligne. Chaque page a sa propre title et description.'
    },
    cms: {
      code: '// WordPress \u2192 th\u00e8me sur mesure\n// Webflow \u2192 sans code, flexible\n// Statiq (Hugo/Eleventy) \u2192 ultra-rapide\n// Solution custom \u2192 contr\u00f4le total\n\n// Crit\u00e8res de choix :\n// \u2022 Autonomie \u00e9quipe\n// \u2022 Volume de contenu\n// \u2022 Budget maintenance\n// \u2022 Besoins sp\u00e9cifiques',
      preview: 'Le bon CMS d\u00e9pend de votre \u00e9quipe \u2014 pas d\u2019une mode',
      insight: 'Je recommande toujours le CMS que votre \u00e9quipe pourra g\u00e9rer seule. L\u2019autonomie apr\u00e8s livraison, c\u2019est un objectif non n\u00e9gociable.'
    }
  };

  window.setWeb = function (key, btn) {
    const code    = document.getElementById('web-code');
    const preview = document.getElementById('web-preview');
    const insight = document.getElementById('web-insight');
    const tabs    = document.querySelectorAll('.web-tab');
    if (!code) return;

    tabs.forEach(function (t) { t.classList.remove('active'); });
    btn.classList.add('active');

    const data = WEB_DATA[key];
    if (!data) return;

    code.innerHTML    = '<pre><code>' + data.code + '</code></pre>';
    preview.innerHTML = '<p class="web-preview-label">' + data.preview + '</p>';
    insight.innerHTML = '<p class="web-insight-text">' + data.insight + '</p>';
  };

  /* ─── FLOW TOGGLE ─── */
  window.toggleFlow = function (node) {
    const isOn = node.classList.contains('on');
    document.querySelectorAll('.flow-node').forEach(function (n) {
      n.classList.remove('on');
    });
    if (!isOn) node.classList.add('on');
  };

  /* ─── FAQ TOGGLE ─── */
  window.toggleFaq = function (questionEl) {
    const item = questionEl.closest('.faq-item') || questionEl.parentElement;
    const isOpen = item.classList.contains('open');
    document.querySelectorAll('.faq-item').forEach(function (f) {
      f.classList.remove('open');
    });
    if (!isOpen) item.classList.add('open');
  };

  /* ─── INITIALISATION ─── */
  document.addEventListener('DOMContentLoaded', function () {
    // Quiz \u2014 rendre Q1
    renderQ(0);

    // \u00c9co panel \u2014 afficher le premier onglet actif
    const firstEcoTab = document.querySelector('.eco-tab.active');
    if (firstEcoTab) {
      const key = firstEcoTab.getAttribute('onclick').match(/'([^']+)'/)[1];
      setEco(key, firstEcoTab);
    }

    // Web panel \u2014 afficher le premier onglet actif
    const firstWebTab = document.querySelector('.web-tab.active');
    if (firstWebTab) {
      const key = firstWebTab.getAttribute('onclick').match(/'([^']+)'/)[1];
      setWeb(key, firstWebTab);
    }
  });

})();
