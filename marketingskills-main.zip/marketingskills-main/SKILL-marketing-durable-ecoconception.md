---
name: marketing-durable-ecoconception
description: |
  Quand l'utilisateur veut intégrer des principes de durabilité, d'écoconception ou de numérique responsable
  dans une stratégie marketing, un projet web ou une identité visuelle.
  Utiliser aussi pour auditer l'empreinte écologique d'un site ou d'une campagne publicitaire, créer du contenu
  à impact réduit, ou positionner une marque sur des valeurs environnementales et sociales (ESG).
  Utiliser également pour conseiller des clients sur l'écoconception d'emballages, de matériaux imprimés,
  ou de communications responsables.
  Mots-clés : "écoconception", "numérique responsable", "marketing durable", "empreinte carbone",
  "design écoresponsable", "logo éthique", "greenwashing", "ESG", "REP Québec",
  "emballage recyclable", "communication responsable".
triggers:
  - écoconception web ou emballage
  - numérique responsable
  - marketing durable / ESG
  - empreinte carbone d'un site ou d'une campagne
  - design graphique écoresponsable
  - positionnement environnemental crédible
  - éviter le greenwashing
  - identité visuelle éthique
  - communication sur les emballages au Québec
  - REP / collecte sélective / recyclabilité
related_skills:
  - product-marketing-context
  - copywriting
  - site-architecture
  - content-strategy
  - page-cro
  - redaction-web-fr-canada
---

# Marketing durable & Écoconception

## Lire d'abord
Consulter `product-marketing-context` pour comprendre les valeurs de marque avant d'intégrer des arguments durables.

---

## Partie 1 — Cadre ESG (Parcours Marketing Durable, Masse Critique 2024)

### Mini-évaluation ESG — 6 axes diagnostiques
Avant toute recommandation, évaluer la maturité ESG du client :

**Gouvernance** — Mission ESG dans les statuts ? Objectifs mesurables ? Rapport de durabilité public ?
**Employés** — Salaire décent ? Culture d'inclusion et d'équité ?
**Communauté** — Soutien aux initiatives locales ? Fournisseurs locaux ou issus de la diversité ?
**Environnement** — Actions pour réduire l'empreinte carbone ? Gestion des déchets, eau ?
**Clients** — Produits/services à impact positif ? Pratiques éthiques dans la chaîne d'approvisionnement ?
**Communication & Marketing** — Transparence sur les engagements ESG ? Directives anti-greenwashing ? Empreinte carbone des campagnes mesurée et réduite ?

### Serment d'Hippocrate des communicants (Masse Critique, 2024)
Cadre éthique à proposer aux clients et équipes :
1. **Efficience et sobriété** — Canaux utilisés de façon mesurée ; réflexion sur l'utilité et l'impact de chaque action.
2. **Pédagogie et clarté** — Informations compréhensibles et contextualisées, adaptées aux publics.
3. **Conseil et alerte** — Signaler toute dérive ou impact négatif.
4. **Sincérité et éthique** — Faits communiqués avec honnêteté, sans déformation.
5. **Humilité** — Reconnaître réussites ET axes d'amélioration.
6. **Durabilité et cohérence** — Engagements réalistes et cohérents avec les capacités réelles de l'entreprise.
7. **Inclusion** — Communication accessible pour tous.

### Analyse des stéréotypes dans les campagnes (Semaine 2)
Analyser 1 à 10 campagnes existantes : qui sont les personnages représentés, comment sont-ils dépeints, quels stéréotypes véhiculés, quel ton de voix.

### Mesure GES des campagnes publicitaires (Semaine 3)
Utiliser le Calculateur des émissions publicitaires de Masse Critique (adapté par COESIO pour le Canada, basé sur les travaux d'EY pour l'AACC France).
- Analyser les périmètres de production et de diffusion
- Résultat en CO2 équivalent
- Identifier les leviers d'optimisation pour les futurs plans médias

---

## Partie 2 — Écoconception des emballages et imprimés (ÉEQ, oct. 2024)

### Définition ÉEQ
L'écoconception est une démarche holistique qui se caractérise par la prise en compte de critères environnementaux, sociaux et économiques lors de la phase de conception d'un emballage ou d'un imprimé, tout en conservant sa valeur d'usage.

### Hiérarchie 3RV-E (ordre de priorité)
1. Réduction à la source
2. Réemploi
3. Recyclage
4. Valorisation des matières
5. Valorisation énergétique
6. Élimination

### Notion de « juste emballage »
- Éviter le sous-emballage (bris, pertes, gaspillage alimentaire)
- Éviter le suremballage (gaspillage de ressources)
- Le meilleur emballage = celui qui remplit sa fonction avec le plus faible impact environnemental

### 3 stratégies d'écoconception

**Réduction**
- Réduire le poids/volume des emballages primaire, secondaire et tertiaire
- Changer la formulation du produit (concentré, solide) pour réduire l'emballage
- Réduire le vide technique non nécessaire
- **Écoencrage** : minimiser la consommation d'encre (taux de couverture, polices, éliminer les zones non visibles)
- Concevoir pour la réutilisation (recharges, vrac)

**Approvisionnement**
- Contenu recyclé postconsommation
- Éliminer les substances toxiques (PFAS, BPA)
- Privilégier l'approvisionnement local (Québec et régions limitrophes)
- Fournisseurs avec certifications : ICI on recycle+, LEED, ISO, B Corp, FSC
- Matières de sources durables/renouvelables

**Recyclabilité**
- Matières acceptées REP : carton, PET, HDPE, plastiques rigides/souples, verre, métaux, aluminium
- Éviter : PVC, plastiques dégradables/compostables, bois, liège, céramique
- Préférer le monomatériau
- Éviter les petits composants (< 2 pouces sur deux côtés)
- Éviter les plastiques noirs avec noir de carbone (non détectables au tri optique)
- Minimiser la surface de couverture des étiquettes

### Emballages compostables — mise en garde
Les infrastructures québécoises ne sont pas adaptées. Les emballages compostables sont retirés et envoyés à l'enfouissement. Ils causent aussi des erreurs de tri. À éviter.

### Bonus incitatif ÉEQ
ÉEQ offre un bonus de 20 % de la contribution payable pour chaque action d'écoconception réalisée (10 actions disponibles, 4 thématiques). Bonus additionnel de 10 % pour une étude de cas.

---

## Partie 3 — Communiquer sur l'écoconception sans greenwashing

### Règle des 3 étapes (ÉEQ)
1. **Lister les améliorations** et choisir les plus pertinentes à communiquer
2. **Appuyer sur des faits** : données quantitatives/comparatives, certifications, preuves accessibles
3. **Informer sans ambiguïté** : message précis, factuel, vérifiable, conforme aux lois

### Les 7 formes de greenwashing à éviter (TerraChoice)
1. Le compromis caché (les inconvénients passés sous silence)
2. L'absence de preuve concrète
3. L'imprécision qui confond
4. Le faux logo ou label mensonger
5. La non-pertinence ou futilité de l'affirmation
6. Le moindre mal (l'envers de la médaille)
7. Le mensonge pur

**Allégations à proscrire sans données vérifiables** : « écologique », « vert », « bon pour la planète », « respectueux de l'environnement », « non polluant », « préserve la nature ».

### Formulations à privilégier (exemples ÉEQ)
- ✓ « Ce nouveau sachet utilise 9 % moins de plastique que l'ancien »
- ✓ « Fait avec 100 % de plastique recyclé »
- ✓ « Notre nouveau verre utilise 17 % moins de plastique — fabrication avec 38 % moins de GES »
- ✓ « Issu de forêts bien gérées [certification FSC] »
- ✗ « Conçu pour être recyclé » (sans preuve)
- ✗ « Emballage respectueux de la nature »
- ✗ « Boîte de carton largement recyclable »

### Ruban de Möbius — utilisation correcte
- Ruban seul = l'emballage est potentiellement recyclable (autodéclaration, non vérifiée)
- % dans le ruban = proportion de matière recyclée dans l'emballage
- Ne jamais apposer le ruban sans indication supplémentaire
- Ne jamais créer des visuels qui ressemblent à des logos certifiés

### Conformité légale (Canada/Québec)
- **Bureau de la concurrence Canada (BCC)** : régit les déclarations environnementales
- Loi sur l'emballage et l'étiquetage des produits de consommation
- **ISO 14021** : encadre les autodéclarations environnementales
- Règlement CS (REP, collecte sélective au Québec)

---

## Partie 4 — Écoconception numérique

### Audit d'empreinte numérique
1. Mesurer avec Website Carbon Calculator ou EcoIndex
2. Identifier les ressources lourdes : images non compressées, scripts tiers, polices multiples, vidéos en autoplay
3. Prioriser : les images représentent souvent 60-70 % du poids de page

### Bonnes pratiques techniques
- Images : formats WebP/AVIF, compression, lazy loading, dimensions adaptées
- Polices : max 2 familles, WOFF2, subset par langue
- Scripts : éliminer les tiers inutiles (trackers, widgets non essentiels)
- CSS : purger les règles inutilisées
- Hébergement : énergie renouvelable (OVH Canada, Greengeeks, etc.)
- CDN pour assets statiques, mise en cache agressive

### Design graphique écoconception
- Palettes sobres (OLED consomme moins sur fond sombre)
- Éviter les animations et effets visuels superflus
- Formats vectoriels (SVG) préférés aux rasters pour les éléments d'interface
- Écoencrage appliqué au graphisme numérique et imprimé
- Conception modulaire et réutilisable

---

## Partie 5 — Identité visuelle éthique et durable

- Conception intemporelle > tendances (moins de redesigns = moins d'empreinte)
- Systèmes graphiques flexibles adaptables à tous les formats
- Typographies avec licences ouvertes
- Documenter les déclinaisons pour limiter les variations anarchiques
- Imprimé : papier FSC ou recyclé, encres végétales/UV, formats standards, impression à la demande

---

## Workflow recommandé

1. **Diagnostiquer** : mini-évaluation ESG (6 axes Masse Critique)
2. **Auditer** : empreinte numérique du site, GES des campagnes, qualité des emballages actuels
3. **Identifier les gains rapides** : images web, scripts, hébergement, réduction d'emballage
4. **Aligner positionnement et pratiques réelles** (anti-greenwashing)
5. **Définir les messages durables vérifiables** (règle des 3 étapes ÉEQ)
6. **Produire le contenu** avec `copywriting` ou `content-strategy`; respecter `redaction-web-fr-canada`
7. **Optimiser la production graphique** (écoencrage, formats vectoriels)
8. **Documenter la démarche** pour crédibiliser les communications futures

---

## Ressources de référence

### Parcours Marketing Durable (Masse Critique, 2024)
- Cahier Semaine 1 — Mini-évaluation ESG (6 axes)
- Cahier Semaine 2 — Serment d'Hippocrate / Analyse des stéréotypes
- Cahier Semaine 3 — Calculateur GES des campagnes publicitaires
- https://www.massecritique.ca/emissions-influence-publicitaire

### Éco Entreprises Québec (ÉEQ)
- Lignes directrices d'écoconception (LDÉ) — octobre 2024
- Lignes directrices de recyclabilité (LDR) — octobre 2024
- Guide de communication sur l'écoconception d'emballage (ÉEQ, 2022)
- FAQ Écoconception (octobre 2024)
- Subventions et bonus incitatifs à l'écoconception
- Tableaux meilleures pratiques : approvisionnement, conception optimisée, gestion fin de vie
- EEQ_LG2 Guide 2023 — Déconstruction des mythes + Optimisation du processus
- https://eeq.ca

### Écoconception web
- Tink.ca : https://www.tink.ca/perspectives/lecoconception-web-une-demarche-appliquee-dans-tous-nos-mandats
- Grenier.qc.ca : https://www.grenier.qc.ca/chroniques/48821/
- Agence Nicely 2025 : https://www.agence-nicely.com/ressources-numerique/blogue-nicely/numerique-responsable/
- BPI France : https://bigmedia.bpifrance.fr/nos-dossiers/eco-conception-web-reduire-lempreinte-carbone-de-son-site-dentreprise
- La Guild : https://www.laguild.io/use-cases/eco-conception-et-design-inclusif

### Design graphique écoresponsable
- Graphiste.com : https://graphiste.com/blog/leco-conception-en-graphisme-pourquoi-et-comment/
- Lucie Colin : https://luciecolin.com/logo-eco-responsable-et-identite-visuelle-ethique/
- *L'écoconception pour les graphistes* — Pyramyd éditions, 2023

### Approvisionnement responsable
- ECPAR : https://www.ecpar.org/fr/achat-responsable
- FSC Canada : https://ca.fsc.org/fr-ca

### Conformité légale
- Bureau de la concurrence Canada : https://www.competitionbureau.gc.ca/
- ISO 14021 — Autodéclarations environnementales
- Loi sur la qualité de l'environnement (LQE), Québec
- Règlement CS (collecte sélective, REP)
