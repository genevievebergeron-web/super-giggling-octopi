# 🔧 Commands - Cheatsheet

> **Référence rapide pour Slash Commands Claude Code**

📄 **Docs** : [Claude Code Commands](https://code.claude.com/docs/slash-commands)

---

## ⚡ Quick Start

### Command Minimale

```markdown
---
name: hello
description: Say hello
---

Dis bonjour à l'utilisateur de manière amicale.
```

**Usage** : `/hello`

---

## 📂 Localisations

| Type | Path | Usage |
|------|------|-------|
| **Projet** | `.claude/commands/` | Partagé avec équipe (Git) |
| **Personnel** | `~/.claude/commands/` | Local, non versionné |

---

## 📝 Structure Fichier

```markdown
---
name: nom-command              # ✅ Requis - kebab-case
description: Description       # ✅ Requis - courte
arguments:
  - name: arg1                 # ❌ Optionnel
    description: Description
    required: true
---

[Prompt en markdown]

## Variables
- `{arg1}` → Arguments
- Markdown complet supporté
```

---

## 🎯 Templates Courants

### 🟢 Simple Command

```markdown
---
name: test
description: Run tests
---

Lance les tests du projet avec npm test et affiche les résultats.
```

### 🟡 Command avec Argument

```markdown
---
name: create-page
description: Créer une nouvelle page
arguments:
  - name: pageName
    description: Nom de la page
    required: true
---

Crée une nouvelle page **{pageName}** avec :
- Component React/Next.js
- Routing automatique
- Tests unitaires
```

**Usage** : `/create-page contact`

### 🟠 Command avec Workflow

```markdown
---
name: epct
description: Workflow EPCT complet
arguments:
  - name: feature
    description: Feature à implémenter
    required: true
---

# EPCT Workflow : {feature}

**E** - Explore le code existant
**P** - Plan détaillé avant implémentation
**C** - Code avec best practices
**T** - Tests et validation

## Étapes
1. Explore architecture
2. Propose plan
3. Implémente code
4. Crée tests
5. Valide résultat
```

---

## 🔥 Exemples Pratiques

### Frontend

```markdown
/create-component Button    # Créer composant
/create-hook useAuth       # Créer custom hook
/create-context Theme      # Créer Context
```

### Backend

```markdown
/create-api users          # Créer endpoint API
/create-migration AddUsers # Créer migration DB
/deploy staging            # Déployer staging
```

### Testing

```markdown
/generate-tests Button.tsx # Générer tests
/coverage                  # Vérifier coverage
/e2e login                 # Tests E2E
```

---

## 💡 Best Practices

✅ **DO** :
- Noms kebab-case : `create-api` ✅
- Descriptions claires
- Arguments documentés
- Markdown structuré
- Workflows réutilisables

❌ **DON'T** :
- camelCase : `createApi` ❌
- Descriptions vagues
- Prompts trop longs
- Duplication de code

---

## 🚀 Organisation

### Par Domaine

```
.claude/commands/
├── frontend/
│   ├── create-component.md
│   └── create-hook.md
├── backend/
│   ├── create-api.md
│   └── create-migration.md
└── testing/
    ├── generate-tests.md
    └── e2e.md
```

### Par Workflow

```
.claude/commands/
├── setup-project.md
├── feature-epct.md
├── bug-fix.md
└── refactor.md
```

---

## 🔧 Debug Commands

```bash
# Lister commands disponibles
/help

# Voir contenu command
cat .claude/commands/ma-command.md

# Valider frontmatter
# Vérifier --- en début/fin
# Pas de tabs, que des espaces
```

---

## 📦 Packs Commands

**Weston Hobson** : https://github.com/wshobson/commands
- `commit.md` - Smart commits
- `refactor.md` - Code refactoring
- `optimize.md` - Performance

**Edmund Yong** : https://github.com/edmund-io/edmunds-claude-code
- `/epct` - Explore/Plan/Code/Test
- `/fix` - Debug & fix
- `/doc` - Documentation

---

## 📚 Ressources

### 📄 Documentation Officielle
- [Slash Commands Docs](https://code.claude.com/docs/en/slash-commands) - Guide officiel Anthropic
- [Agent SDK - Slash Commands](https://docs.claude.com/en/docs/agent-sdk/slash-commands) - Documentation détaillée SDK
- [Commands Best Practices](https://code.claude.com/docs/en/slash-commands#best-practices) - Patterns recommandés

### 🎥 Vidéos Recommandées
- [Terminal AI Workflow](../../ressources/videos/terminal-ai-workflow.md) ([🔗 YouTube](https://youtu.be/MsQACpcuTkU)) - NetworkChuck | 🟢 Débutant
  - Workflow complet avec commands
- [Formation Claude Code 2.0](../../ressources/videos/formation-claude-code-2-0-melvynx.md) ([🔗 YouTube](https://www.youtube.com/watch?v=bDr1tGskTdw)) - Melvynx | 🟢 Débutant
  - Introduction aux commands
- [Skills vs Slash Commands vs Sub-Agents vs MCP - Le Guide Complet](../../ressources/videos/skills-vs-slash-commands-vs-subagents-vs-mcp-dan.md) ([🔗 YouTube](https://www.youtube.com/watch?v=kFpLzCVLA20)) - Dan | 🟠 Avancé
  - Slash commands comme primitive fondamentale, quand passer à un skill, compositional hierarchy
- [800h Claude Code](../../ressources/videos/800h-claude-code-edmund-yong.md) ([🔗 YouTube](https://www.youtube.com/watch?v=Ffh9OeJ7yxw)) - Edmund Yong | 🔴 Expert
  - Commands avancés et EPCT

### 📝 Articles
- [Skills, Commands, Subagents, Plugins](../../ressources/articles/skills-commands-subagents-plugins-youngleaders.md) ([🔗 Source](https://www.youngleaders.tech/p/claude-skills-commands-subagents-plugins)) - YoungLeaders
  - Quand utiliser Commands vs autres features
- [Understanding Claude Code's Full Stack](../../ressources/articles/full-stack-orchestration-opalic.md) ([🔗 Source](https://alexop.dev/posts/understanding-claude-code-full-stack/)) - Alexander Opalic
  - Commands dans l'architecture : user-triggered workflows, explicit control

### 🔗 Communauté
- [Awesome Claude Code](https://github.com/hesreallyhim/awesome-claude-code) ⭐ 17K - Liste curée commands & workflows
- [Weston Hobson Commands](https://github.com/wshobson/commands) - Collection de commands pro
- [Edmund Yong Setup](https://github.com/edmund-io/edmunds-claude-code) - EPCT et workflows
- [Awesome Commands](https://github.com/VoltAgent/awesome-claude-code#commands) - Liste communautaire

---

**💡 Tip** : Commence par EPCT, c'est le workflow le plus puissant ! 🚀
